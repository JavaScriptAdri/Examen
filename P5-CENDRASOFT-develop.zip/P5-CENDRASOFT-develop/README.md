# CENDRASOFT

### Gestor de Coneixement per Organitzacions

CENDRASOFT és una eina dissenyada per abordar un dels grans problemes de les grans organitzacions: la pèrdua de coneixement. Sovint, la informació generada en tasques, gestions o processos no queda guardada enlloc, i pot perdre's amb canvis d'equip, lloc de treball o responsabilitats. **CENDRASOFT** centralitza, uniformitza i sistematitza la gestió del coneixement de l'organització.

---

## Objectius Principals

1. **Cerca d'informació fàcil i eficient**: L'usuari ha de poder trobar la informació necessària i relacionada de manera ràpida i senzilla.
2. **Afegir informació amb facilitat**: El procés per incorporar o actualitzar coneixements ha de ser intuïtiu i sense passos innecessaris, per garantir que els usuaris utilitzin l'eina de manera constant.

---

## Característiques del Producte Mínim Viable (PMV)

El projecte es divideix en dues fases (sprints). Aquestes són les funcionalitats incloses en el **primer sprint**:

### Funcionalitats:
- **Gestió de Coneixements**:
  - ID, títol, descripció, categoria, autor, etiquetes.
- **Categories**:
  - ID i nom.
- **Usuaris i permisos**:
  - Els usuaris registrats poden crear articles i editar només els que han creat.
- **Login amb OAuth**:
  - Com a mínim, suport per Google i GitHub.
- **Part pública**:
  - Consultar articles.
  - Filtrar articles per categories.
  - Cercar articles mitjançant AJAX (en títol, descripció, etiquetes i autor).

### Consideracions generals:
- **Desplegament**:
  - El projecte es desplega al servidor seguint les instruccions del projecte.
- **Disseny adaptable**:
  - Compatible amb dispositius mòbils i escriptoris.
- **Accessibilitat**:
  - Nivell AA a la part pública.

---

## Tecnologies Utilitzades

- **Backend**: PHP
- **Frontend**: Vue.js, JavaScript
- **Altres**: AJAX per cerca dinàmica, OAuth per autenticació
- **Estil i estructuració**: Editor Markdown per articles visuals i estructurats.

---

## Instal·lació i Configuració

1. **Clona el repositori**:
   ```bash
   git clone https://github.com/ABP-2n-DAW-24-25/P5-CENDRASOFT.git
   cd P5-CENDRASOFT
# CENDRASOFT

### Knowledge Management Tool for Organizations

CENDRASOFT is a tool designed to address one of the major issues faced by large organizations: the loss of knowledge. Often, information generated during tasks, processes, or operations is not saved anywhere, resulting in its loss when teams, roles, or responsibilities change. **CENDRASOFT** centralizes, standardizes, and systematizes the organization's knowledge management.

---

## Main Objectives

1. **Easy and efficient information search**: Users must be able to quickly and easily find the information they need, as well as related information.
2. **Simplified information addition**: The process of adding or updating knowledge must be intuitive and hassle-free, ensuring users actively use the tool.

---

## Features of the Minimum Viable Product (MVP)

The project is divided into two phases (sprints). The **first sprint** includes the following functionalities:

### Features:
- **Knowledge Management**:
  - ID, title, description, category, author, tags.
- **Categories**:
  - ID and name.
- **Users and Permissions**:
  - Registered users can create articles and edit the ones they have created.
- **OAuth Login**:
  - At least support for Google and GitHub authentication.
- **Public Section**:
  - View articles.
  - Filter articles by category.
  - Search articles via AJAX (search by title, description, tags, and author).

### General Considerations:
- **Deployment**:
  - The project should be deployed following the provided server instructions.
- **Responsive Design**:
  - Compatible with both mobile and desktop devices.
- **Accessibility**:
  - Ensure AA accessibility level in the public section.

---

## Technologies Used

- **Backend**: PHP
- **Frontend**: Vue.js, JavaScript
- **Others**: AJAX for dynamic search, OAuth for authentication
- **Content Editing**: Markdown editor for creating structured and visually appealing articles.

---

## Installation and Setup

1. **Clone the repository**:
   ```bash
   git clone https://github.com/ABP-2n-DAW-24-25/P5-CENDRASOFT.git
   cd P5-CENDRASOFT
