<?php

namespace App\Http\Controllers;

use App\Models\Article;
use Illuminate\Http\Request;
use Inertia\Inertia;
use Inertia\Response;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Auth;

class ArticleController extends Controller
{
    /**
     * Display paginated list of articles for the current user
     */
    public function index(): Response
    {
        $articles = Article::with('user')
            ->forCurrentUser()
            ->latest()
            ->paginate(6);

        return Inertia::render('Article', [
            'articles' => $articles
        ]);
    }

    /**
     * Show single article details
     */
    public function show($id): Response
    {
        $article = Article::with('user')->findOrFail($id);

        return Inertia::render('ShowArticle', [
            'article' => $article,
        ]);
    }

    /**
     * Search articles for authenticated users with filtering options
     */
    public function search(Request $request)
    {
        $query = Article::with('user')->forCurrentUser();

        if ($request->has('title')) {
            $query->where('title', 'like', '%' . $request->title . '%');
        }

        if ($request->has('description')) {
            $query->where('description', 'like', '%' . $request->description . '%');
        }

        if ($request->has('labels')) {
            $searchLabel = $request->labels;
            $query->whereRaw('JSON_SEARCH(LOWER(labels), "one", LOWER(?)) IS NOT NULL', ['%' . $searchLabel . '%']);
        }

        // General search across multiple fields
        if ($request->has('query')) {
            $searchTerm = $request->input('query');
            $query->where(function ($q) use ($searchTerm) {
                $q->where('title', 'like', '%' . $searchTerm . '%')
                    ->orWhere('description', 'like', '%' . $searchTerm . '%')
                    ->orWhereRaw('JSON_SEARCH(LOWER(labels), "one", LOWER(?)) IS NOT NULL', ['%' . $searchTerm . '%']);
            });
        }

        $articles = $query->latest()->paginate(6);
        $articles->appends($request->except('page'));

        return response()->json($articles);
    }

    /**
     * Search articles for public access with additional author filtering
     */
    public function publicSearch(Request $request)
    {
        $query = Article::with('user');

        if ($request->has('title')) {
            $query->where('title', 'like', '%' . $request->title . '%');
        }

        if ($request->has('description')) {
            $query->where('description', 'like', '%' . $request->description . '%');
        }

        if ($request->has('author')) {
            $authorName = $request->author;
            $query->whereHas('user', function ($q) use ($authorName) {
                $q->where('name', 'like', '%' . $authorName . '%')
                    ->orWhere('username', 'like', '%' . $authorName . '%');
            });
        }

        if ($request->has('labels')) {
            $searchLabel = $request->labels;
            $query->whereRaw('JSON_SEARCH(LOWER(labels), "one", LOWER(?)) IS NOT NULL', ['%' . $searchLabel . '%']);
        }

        // General search across multiple fields including author
        if ($request->has('query')) {
            $searchTerm = $request->input('query');
            $query->where(function ($q) use ($searchTerm) {
                $q->where('title', 'like', '%' . $searchTerm . '%')
                    ->orWhere('description', 'like', '%' . $searchTerm . '%')
                    ->orWhereHas('user', function ($subq) use ($searchTerm) {
                        $subq->where('name', 'like', '%' . $searchTerm . '%')
                            ->orWhere('username', 'like', '%' . $searchTerm . '%');
                    })
                    ->orWhereRaw('JSON_SEARCH(LOWER(labels), "one", LOWER(?)) IS NOT NULL', ['%' . $searchTerm . '%']);
            });
        }

        $articles = $query->latest()->paginate(6);
        $articles->appends($request->except('page'));

        return response()->json($articles);
    }

    /**
     * Display article creation form
     */
    public function create()
    {
        return Inertia::render('Article/Create');
    }

    /**
     * Store a newly created article
     */
    public function store(Request $request)
    {
        $fields = $request->validate([
            'title' => ['required', 'max:40'],
            'description' => ['required'],
            'labels' => ['required', 'json'],
            'category_id' => ['required'],
            'image' => ['nullable', 'file', 'max:3072', 'mimes:jpeg,jpg,png,webp']
        ]);

        $fields['labels'] = json_decode($fields['labels']);

        // Handle image upload if present
        if ($request->hasFile('image')) {
            $fields['image'] = Storage::disk('public')->put(
                'images/article',
                $request->image
            );
        }

        $request->user()->articles()->create($fields);

        return redirect()->route('article')->with('status', 'Article creat correctament');
    }

    /**
     * Display article edit form with authorization check
     */
    public function edit(Article $article)
    {
        if ($article->user_id !== Auth::id()) {
            return redirect()->route('article')->with('error', 'No tens permís per editar aquest article');
        }

        return Inertia::render('Article/Edit', [
            'article' => $article,
        ]);
    }

    /**
     * Update article with authorization check
     */
    public function update(Request $request, Article $article)
    {
        if ($article->user_id !== Auth::id()) {
            return redirect()->back()->with('error', 'No tens permís per editar aquest article');
        }

        $fields = $request->validate([
            'title' => ['required', 'max:40'],
            'description' => ['required'],
            'labels' => ['required', 'json'],
            'category_id' => ['required'],
            'image' => ['nullable', 'file', 'max:3072', 'mimes:jpeg,jpg,png,webp'],
            '_removeImage' => ['nullable', 'boolean']
        ]);

        // Remove non-model field
        $removeImage = $fields['_removeImage'] ?? false;
        unset($fields['_removeImage']);

        $fields['labels'] = json_decode($fields['labels']);

        // Handle image scenarios
        if ($request->hasFile('image')) {
            // Case 1: New image uploaded - replace old one
            if ($article->image && Storage::disk('public')->exists($article->image)) {
                Storage::disk('public')->delete($article->image);
            }
            
            $fields['image'] = Storage::disk('public')->put(
                'images/article',
                $request->image
            );
        } elseif ($removeImage) {
            // Case 2: Request to remove image without uploading new one
            if ($article->image && Storage::disk('public')->exists($article->image)) {
                Storage::disk('public')->delete($article->image);
            }
            $fields['image'] = null;
        } else {
            unset($fields['image']); 
        }

        $article->update($fields);

        return redirect()->route('article')->with('status', 'Article actualitzat correctament');
    }

    /**
     * Delete article with authorization check
     */
    public function destroy(Article $article)
    {
        if ($article->user_id !== Auth::id()) {
            return redirect()->back()->with('error', 'No tens permís per eliminar aquest article');
        }

        $article->delete();

        return redirect()->route('article')->with('status', 'Article eliminat correctament');
    }

    /**
     * Show article to guest users
     */
    public function guestShow($id)
    {
        $article = Article::with('user')->findOrFail($id);

        return Inertia::render('GuestArticleView', [
            'article' => $article,
        ]);
    }
}
