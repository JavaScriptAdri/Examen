<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Facades\Auth;

class Article extends Model
{
    use HasFactory;

    /**
     * Fields that can be mass-assigned
     */
    protected $fillable = [
        'title',
        'description',
        'labels',
        'user_id',
        'category_id',
        'image',
    ];

    /**
     * Attributes that should be cast
     */
    protected $casts = [
        'labels' => 'array',
    ];

    /**
     * Get the user who created this article
     */
    public function user()
    {
        return $this->belongsTo(User::class);
    }

    /**
     * Scope for retrieving only articles belonging to current user
     */
    public function scopeForCurrentUser(Builder $query): Builder
    {
        return $query->where('user_id', Auth::id() ?: 0);
    }
    
    /**
     * Get the fully qualified URL for the article's image
     */
    public function getImageUrlAttribute()
    {
        if (!$this->image) {
            return null;
        }
        
        return url('storage/' . $this->image);
    }
}
