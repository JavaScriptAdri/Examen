<?php

declare(strict_types=1);

return [
    'failed' => 'Les credencials introduïdes no coincideixen amb els nostres registres.',
    'password' => 'La contrasenya introduïda és incorrecta.',
    'throttle' => 'Masses intents de connexió. Si us plau, torna-ho a provar en :seconds segons.',
];
