<script setup>
const props = defineProps({
    paginator: Object, // Pagination data object with links and metadata
});

const emit = defineEmits(['paginate']);

/**
 * Handle pagination navigation
 * @param {string|null} url - The URL to navigate to
 */
const changePage = (url) => {
    if (!url) return;
    emit('paginate', url);
};

/**
 * Format navigation labels for better display
 */
const makeLabel = (label) => {
    if (label.includes("Anterior")) {
        return "<<";
    } else if (label.includes("Següent")) {
        return ">>";
    } else {
        return label;
    }
};
</script>

<template>
    <div class="flex justify-between items-start">
        <!-- Pagination buttons -->
        <div class="flex items-center rounded-md overflow-hidden shadow-lg">
            <div v-for="(link, i) in props.paginator.links" :key="i">
                <button 
                    @click="changePage(link.url)" 
                    v-html="makeLabel(link.label)"
                    class="border-x border-slate-50 w-12 h-12 grid place-items-center bg-white" 
                    :class="{
                        'hover:bg-slate-300': link.url,
                        'text-slate-300': !link.url,
                        'font-bold text-black': link.active,
                    }"
                    :disabled="!link.url"
                    type="button"
                />
            </div>
        </div>

        <!-- Results counter -->
        <p class="text-slate-600 text-sm">
            Mostrant {{ props.paginator.to }} de
            {{ props.paginator.total }} resultats
        </p>
    </div>
</template>