<template>
  <img alt="logotip" src="../../../public/logo.png" >
</template>
