<script setup>
import { Link, router, usePage } from '@inertiajs/vue3';
import { computed } from 'vue';

const props = defineProps({
    article: Object,
});

const emit = defineEmits(['view-article']);

// Check if current user is the article owner
const isOwner = computed(() => {
    return props.article.user_id === usePage().props.auth.user?.id;
});

// Handle article deletion with confirmation
const deleteArticle = () => {
    if (confirm('Estàs segur que vols eliminar aquest article?')) {
        router.delete(`/article/${props.article.id}`);
    }
};
</script>

<template>
    <div class="cursor-pointer bg-white rounded-lg shadow-lg overflow-hidden bg-gradient-to-r from-purple-500 to-pink-500 h-full flex flex-col justify-between">
        <div>
            <!-- Article image -->
            <img :src="article.image ? `/storage/${article.image}` : '/storage/images/article/default.jpg'" 
                class="w-full h-48 object-cover object-center bg-slate-300"
                alt="article image">
            
            <!-- Article title and author info -->
            <div class="p-4">
                <h2 class="font-bold text-xl mb-2 text-white">
                    {{ article.title.substring(0, 45) }}
                </h2>
                <p class="text-white">
                    Creat el: {{ new Date(article.created_at).toLocaleDateString() }} 
                    <br> 
                    {{ article.user.name }}
                </p>
            </div>
            
            <!-- Article labels/tags -->
            <div v-if="article.labels" class="flex flex-wrap items-center gap-3 px-4 pb-4">
                <div v-for="label in article.labels" :key="label">
                    <span class="bg-blue-800 text-white px-2 py-px rounded-full">
                        {{ label }}
                    </span>
                </div>
            </div>
        </div>
        
        <!-- Owner-only actions (edit/delete) -->
        <div v-if="isOwner" class="p-4 flex justify-end gap-2 border-t border-white/10">
            <Link :href="`/article/${article.id}/edit`" 
                class="px-3 py-1 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors">
                Editar
            </Link>
            <button @click.prevent="deleteArticle" 
                class="px-3 py-1 bg-red-600 text-white rounded-md hover:bg-red-700 transition-colors">
                Eliminar
            </button>
        </div>
        
        <!-- View article button -->
        <button 
            @click="$emit('view-article', article.id)" 
            class="block w-full p-4 text-center bg-white/10 hover:bg-white/20 transition-colors"
        >
            <span class="text-white">Veure més</span>
        </button>
    </div>
</template>