<script setup>
import { ref } from 'vue';
import Cookies from 'js-cookie';

// Check if user has already accepted cookies
const cookieAccepted = ref(Cookies.get('cookiesAccepted') === 'true');

// Set cookie when user accepts
const acceptCookies = () => {
  Cookies.set('cookiesAccepted', 'true', { expires: 365 }); // Set the cookie for 1 year
  cookieAccepted.value = true;
};
</script>

<template>
  <div v-if="!cookieAccepted" class="fixed bottom-0 left-0 w-full bg-gray-800 text-white p-4 flex justify-between items-center z-50">
    <div class="flex items-center">
      <p class="mr-4">
        Utilitzem cookies per millorar la teva experiència. Al continuar, acceptes la nostra política de cookies.
      </p>
      <a href="/cookie-policy" class="underline">Llegir mes</a>
    </div>
    <button @click="acceptCookies" class="bg-red-600 px-6 py-2 rounded-md text-white hover:bg-red-700">
      Acceptar 
    </button>
  </div>
</template>

