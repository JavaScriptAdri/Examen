<script setup>
// Accept errors object from parent component
defineProps({
    errors: Object,
});
</script>

<template>
    <!-- Display error messages only when errors exist -->
    <div class="mb-4" v-if="Object.keys(errors).length">
        <p class="text-sm text-red-500">!!!</p>
        <ul class="ml-4 list-disc list-inside">
            <li v-for="(error, i) in errors" :key="i" class="text-sm text-red-500">
                {{ error }}
            </li>
        </ul>
    </div>
</template>