<template>
  <footer class="bg-gray-50 dark:bg-gray-900 text-gray-800 dark:text-gray-200 py-8">
    <div class="container mx-auto grid grid-cols-1 md:grid-cols-4 gap-6 max-w-[90%] text-sm">
      <!-- Legal links section -->
      <div>
        <h2 class="font-semibold mb-4 text-xl">Legal</h2>
        <ul>
          <li><a href="/legal-notice" class="hover:underline text-lg">Avís legal</a></li>
          <li><a href="/cookie-policy" class="hover:underline text-lg">Política de cookies</a></li>
          <li><a href="/privacy-policy" class="hover:underline text-lg">Política de privacitat</a></li>
        </ul>
      </div>

      <!-- About us section -->
      <div>
        <h2 class="font-semibold mb-4 text-xl">Sobre nosaltres</h2>
        <ul>
          <li><a href="/contact" class="hover:underline text-lg">Contacte</a></li>
          <li><a href="/developers" class="hover:underline text-lg">Desenvolupadors</a></li>
        </ul>
      </div>

      <!-- Social media links -->
      <div>
        <h2 class="font-semibold mb-4 text-xl">Xarxes socials</h2>
        <div class="flex space-x-4">
          <a href="https://www.instagram.com/ilov_ejobs/" target="_blank" rel="noopener noreferrer" aria-label="Instagram">
            <svg
              class="icon fill-gray-800 dark:fill-gray-200 hover:fill-red-500 dark:hover:fill-red-500"
              viewBox="0 0 24 24"
            >
            <path d="M7.8,2H16.2C19.4,2 22,4.6 22,7.8V16.2A5.8,5.8 0 0,1 16.2,22H7.8C4.6,22 2,19.4 2,16.2V7.8A5.8,5.8 0 0,1 7.8,2M7.6,4A3.6,3.6 0 0,0 4,7.6V16.4C4,18.39 5.61,20 7.6,20H16.4A3.6,3.6 0 0,0 20,16.4V7.6C20,5.61 18.39,4 16.4,4H7.6M17.25,5.5A1.25,1.25 0 0,1 18.5,6.75A1.25,1.25 0 0,1 17.25,8A1.25,1.25 0 0,1 16,6.75A1.25,1.25 0 0,1 17.25,5.5M12,7A5,5 0 0,1 17,12A5,5 0 0,1 12,17A5,5 0 0,1 7,12A5,5 0 0,1 12,7M12,9A3,3 0 0,0 9,12A3,3 0 0,0 12,15A3,3 0 0,0 15,12A3,3 0 0,0 12,9Z"/>
            </svg>
          </a>
          <a href="https://www.tiktok.com/@user8702097953319" target="_blank" rel="noopener noreferrer" aria-label="Tiktok">
            <svg
              class="icon fill-gray-800 dark:fill-gray-200 hover:fill-red-500 dark:hover:fill-red-500"
              viewBox="0 0 24 24"
            >
            <path d="M12.205 2.039h3.407s-.19 4.376 4.73 4.684v3.382s-2.625.165-4.73-1.442l.036 6.984a6.314 6.314 0 11-6.314-6.313h.886v3.458a2.87 2.87 0 102.016 2.741l-.031-13.494z"/>
            </svg>
          </a>
          <a href="https://x.com/i_love_jobs" target="_blank" rel="noopener noreferrer" aria-label="Twitter">
            <svg class="icon fill-gray-800 dark:fill-gray-200 hover:fill-red-500 dark:hover:fill-red-500" viewBox="0 0 24 24">
              <path d="m3.322 2.88 6.824 9.949L2.99 21.12h1.525l6.307 -7.307L15.833 21.12H20.64L13.499 10.71 20.257 2.88h-1.524l-5.909 6.846L8.128 2.88z"/>
            </svg>
          </a>
          <a href="https://www.youtube.com/@ILoveJobs-5" target="_blank" rel="noopener noreferrer" aria-label="Youtube">
            <svg
              class="icon fill-gray-800 dark:fill-gray-200 hover:fill-red-500 dark:hover:fill-red-500"
              viewBox="0 0 24 24"
            >
              <path d="M23.5 6.5c-.26-1.5-1.5-2.7-3-3C18.2 3 12 3 12 3s-6.2 0-8.5.5c-1.5.3-2.7 1.5-3 3 .5-2.3.5-5.5.5-5.5s0-3.2-.5-5.5zM9.5 15.5v-7l6.5 3.5-6.5 3.5z" />
            </svg>
          </a>
          <a href="https://facebook.com" target="_blank" rel="noopener noreferrer" aria-label="Facebook">
            <svg
              class="icon fill-gray-800 dark:fill-gray-200 hover:fill-red-500 dark:hover:fill-red-500"
              viewBox="0 0 24 24"
            >
            <path d="M16.563 8.424h-3.12V6.378c0-.769.51-.948.868-.948h2.202V2.05l-3.033-.012c-3.366 0-4.132 2.52-4.132 4.133v2.252H7.4v3.482h1.947v9.852h4.095v-9.852h2.763l.357-3.482z"/>
            </svg>
          </a>
        </div>
      </div>
    </div>

    <hr class="border-gray-300 dark:border-gray-600 my-8 max-w-[92%] mx-auto">

    <!-- App download section -->
    <div class="container mx-auto mt-8 text-gray-800 dark:text-gray-200 text-sm text-left max-w-[92%] px-4">
      <h2 class="font-semibold mb-4 text-xl">Aconsegueix l'app properament!</h2>
      <div class="flex space-x-4 items-center">
      <a href="https://play.google.com/store/apps" target="_blank" rel="noopener noreferrer">
        <img src="/public/googleplay.png" alt="Google Play" class="h-12">
      </a>
      <a href="https://www.apple.com/es/app-store/" target="_blank" rel="noopener noreferrer">
        <img src="/public/appstore.png" alt="App Store" class="h-12">
      </a>
      </div>
    </div>

    <!-- Company presentation text -->
    <div class="container mx-auto mt-8 text-gray-800 dark:text-gray-200 text-sm text-left max-w-[92%] px-4">
      <p>
      "Cendrasoft" és l'aplicació que revoluciona la manera de Cercar informació. 
      Creiem que trobar una bona informació hauria de ser més fàcil, entretingut i eficient, sense haver de perdre temps amb processos complicats i poc pràctics. Amb "Cendrasoft", podràs explorar articles de manera àgil gràcies al nostre sistema intuïtiu de selecció.  
      </p>
      
      <p class="mt-4">
      A Cendrasoft cada decisió està a les teves mans, permetent-te avançar només amb les opcions que s'ajusten al que realment estàs buscant.
      Amb el nostre enfocament innovador, transformem el procés de trobar articles en una experiència dinàmica i pràctica, adaptada als ritmes de la vida moderna. 
      Comença avui mateix i descobreix com "Cendrasoft" pot ajudar-te a trobar la informació que desitges!
      </p>
    </div>

    <hr class="border-gray-300 dark:border-gray-600 my-8 max-w-[92%] mx-auto">

    <!-- Footer navigation and copyright -->
    <div class="container mx-auto flex flex-col md:flex-row justify-between items-center text-gray-800 dark:text-gray-200 mt-8 text-sm px-4 max-w-[92%]">
      <div class="space-x-2 mb-4 md:mb-0">
      <a href="/contact" class="hover:underline">Contacte</a> /
      <a href="/developers" class="hover:underline">Desenvolupadors</a> /
      <a href="/legal-notice" class="hover:underline">Avís Legal</a> /
      <a href="/privacy-policy" class="hover:underline">Privacitat</a>
      </div>
      <div class="text-center md:text-right">
        © 2025 Cendrasoft, tots els drets reservats.
      </div>
    </div>
  </footer>
</template>

<style scoped>
.icon {
  height: 24px;
  width: 24px;
  transition: fill 0.2s ease;
}
</style>