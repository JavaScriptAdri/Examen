<script setup>
import { ref } from "vue";

const emit = defineEmits(['image'])

// Track image preview URL
const preview = ref(null);
// Track if selected image exceeds size limit
const oversizedImage = ref(false);

/**
 * Handle image selection and validation
 */
const imageSelected = (e) => {
    preview.value = URL.createObjectURL(e.target.files[0]);
    oversizedImage.value = e.target.files[0].size > 3145728; // Check if > 3MB
    emit('image', e.target.files[0])
};
</script>

<template>
    <div>
        <!-- Label with dynamic text based on image size -->
        <span class="block text-sm font-medium text-slate-700 dark:text-slate-300"
            :class="{ '!text-red-500': oversizedImage }">
            {{
                oversizedImage
                    ? "L'imatge excedeix 3Mb"
                    : "Imatge (Max 3Mb)"
            }}
        </span>

        <!-- Image preview area that acts as file input trigger -->
        <label for="image"
            class="block rounded-md mt-1 bg-slate-300 h-[140px] overflow-hidden cursor-pointer border-slate-300 border"
            :class="{ '!border-red-500': oversizedImage }">
            <img :src="preview ?? '/storage/images/article/default.jpg'"
                class="object-cover object-center h-full w-full" alt="" />
        </label>

        <!-- Hidden file input -->
        <input @input="imageSelected" type="file" name="image" id="image" hidden />
    </div>
</template>