<script setup>
// Two-way binding with parent component
const model = defineModel();

// Component props configuration
defineProps({
    label: String,
    icon: String,
    placeholder: {
        type: String,
        default: "",
    },
    type: {
        type: String,
        default: "text",
    },
});
</script>

<template>
    <div>
        <!-- Input field label -->
        <label :for="label" class="block text-sm font-medium text-black">
            {{ label }}
        </label>

        <div class="relative mt-1 rounded-md">
            <!-- Icon container -->
            <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                <span class="grid place-content-center text-sm text-slate-400">
                    <i :class="`fa-solid fa-${icon}`"></i>
                </span>
            </div>
            <!-- Input with icon positioning -->
            <input :type="type" :name="label" :placeholder="placeholder" v-model="model"
                class="block w-full rounded-md pr-3 pl-9 text-sm dark:text-slate-900 border-slate-300 outline-0 focus:ring-1 focus:ring-inset focus:ring-indigo-400 focus:border-indigo-400 placeholder:text-slate-400" />
        </div>
    </div>
</template>