<script setup>
import { Link } from '@inertiajs/vue3';

const props = defineProps({
    paginator: Object, // Pagination data with links and metadata
});

/**
 * Format pagination labels for better display
 */
const makeLabel = (label) => {
    if (label.includes("Anterior")) {
        return "<<";
    } else if (label.includes("Següent")) {
        return ">>";
    } else {
        return label;
    }
};
</script>

<template>
    <div class="flex justify-between items-start">
        <!-- Pagination buttons -->
        <div class="flex items-center rounded-md overflow-hidden shadow-lg">
            <div v-for="(link, i) in props.paginator.links" :key="i" class="relative">
                <component :is="link.url ? Link : 'span'" :href="link.url" v-html="makeLabel(link.label)"
                    class="border-x border-slate-50 w-12 h-12 grid place-items-center bg-white" :class="{
                        'hover:bg-slate-300': link.url,
                        'text-slate-300': !link.url,
                        'font-bold text-black': link.active,
                    }" />
                <!-- Highlight bar for active page -->
                <div v-if="link.active"
                    class="absolute bottom-0 left-0 w-full h-1 bg-gradient-to-r from-purple-500 to-pink-500">
                </div>
            </div>
        </div>

        <!-- Results counter -->
        <p class="text-slate-600 text-sm">
            Mostrant {{ props.paginator.to }} de
            {{ props.paginator.total }} resultats
        </p>
    </div>
</template>