<script setup>
// Two-way binding with parent component
const model = defineModel();

// Component props configuration
defineProps({
    label: String,
    icon: String,
    placeholder: {
        type: String,
        default: "",
    },
});
</script>

<template>
    <div>
        <!-- Textarea label -->
        <label :for="label" class="block text-sm font-medium text-black">
            {{ label }}
        </label>

        <div class="relative mt-1 rounded-md">
            <!-- Icon container - positioned for textarea -->
            <div class="pointer-events-none absolute top-3 left-0 flex items-center pl-3">
                <span class="grid place-content-center text-sm text-slate-400">
                    <i :class="`fa-solid fa-${icon}`"></i>
                </span>
            </div>
            <!-- Multi-line textarea with icon positioning -->
            <textarea rows="6" :name="label" :placeholder="placeholder" v-model="model"
                class="block w-full rounded-md pr-3 pl-9 text-sm dark:text-slate-900 border-slate-300 outline-0 focus:ring-1 focus:ring-inset focus:ring-indigo-400 focus:border-indigo-400 placeholder:text-slate-400"></textarea>
        </div>
    </div>
</template>