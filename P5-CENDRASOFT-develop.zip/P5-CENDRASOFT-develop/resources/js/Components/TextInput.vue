<script setup>
import { onMounted, ref } from 'vue';

defineProps({
    type: {
        type: String,
        default: 'text',
    },
    placeholder: {
        type: String,
        default: '',
    },
});

// Define two-way binding
const model = defineModel();
// Reference to the input element
const input = ref(null);

// Auto-focus on mount if autofocus attribute exists
onMounted(() => {
    if (input.value.hasAttribute('autofocus')) {
        input.value.focus();
    }
});

// Expose focus method to parent components
defineExpose({ focus: () => input.value.focus() });
</script>

<template>
    <input class="border-gray-300 focus:border-indigo-500 focus:ring-indigo-500 rounded-md shadow-sm" :type="type"
        :value="model" @input="$emit('update:modelValue', $event.target.value)" ref="input"
        :placeholder="placeholder || (type === 'email' ? 'Introdueix el teu correu electrònic' : type === 'password' ? 'Introdueix la teva contrasenya' : '')">
</template>
