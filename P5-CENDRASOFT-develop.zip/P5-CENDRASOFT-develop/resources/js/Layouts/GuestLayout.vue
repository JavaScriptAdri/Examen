<script setup>
import ApplicationLogo from '@/Components/ApplicationLogo.vue';
import { Link } from '@inertiajs/vue3';
</script>

<template>
    <div class="flex min-h-screen flex-col items-center bg-gray-100 pt-6 sm:justify-center sm:pt-0">
        <!-- Application logo with home link -->
        <div>
            <Link href="/">
            <ApplicationLogo class="max-h-40 fill-current" />
            </Link>
        </div>

        <!-- Main content container -->
        <div class="mt-6 w-screen h-100 overflow-hidden bg-white px-12 py-12 shadow-md sm:max-w-md sm:rounded-lg">
            <slot />
        </div>
    </div>
</template>