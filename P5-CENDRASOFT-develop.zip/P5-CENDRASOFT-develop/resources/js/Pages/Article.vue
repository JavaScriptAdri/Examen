<script setup>
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';
import { Head, router } from '@inertiajs/vue3';
import Card from '@/Components/Card.vue';
import PaginationLinks from '@/Components/PaginationLinks.vue';
import AjaxPaginationLinks from '@/Components/AjaxPaginationLinks.vue';
import { ref, watch } from 'vue';
import axios from 'axios';

const props = defineProps({
    articles: Object,
});

// Search state variables
const searchQuery = ref('');
const searchType = ref('query');
const searchResults = ref(null);
const isSearching = ref(false);

// Perform AJAX search based on query and type
const search = async () => {
    if (!searchQuery.value) {
        searchResults.value = null;
        return;
    }

    isSearching.value = true;

    try {
        const params = {};
        params[searchType.value] = searchQuery.value;

        const response = await axios.get('/articles/api/search', { params });
        searchResults.value = response.data;
    } finally {
        isSearching.value = false;
    }
};

// Handle pagination for search results
const handleAjaxPagination = async (url) => {
    if (!url) return;

    isSearching.value = true;
    try {
        const urlObj = new URL(url);

        if (searchQuery.value) {
            urlObj.searchParams.set(searchType.value, searchQuery.value);
        }

        const response = await axios.get(urlObj.toString());
        searchResults.value = response.data;
    } finally {
        isSearching.value = false;
    }
};

// Trigger search when query or type changes
watch(searchQuery, search);
watch(searchType, search);

// Navigate to article detail page
const viewArticle = (articleId) => {
    router.visit(`/articles/${articleId}`);
};
</script>

<template>

    <Head title="Els meus articles" />

    <AuthenticatedLayout>
        <template #header>
            <h1 class="text-xl font-semibold leading-tight text-gray-800 animate-fade-down animate-once">
                Els meus articles
            </h1>
        </template>

        <div class="py-12 bg-gradient-to-br from-blue-100 via-purple-200 to-pink-100">
            <div class="mx-auto max-w-7xl sm:px-6 lg:px-8">
                <!-- Search form -->
                <div class="bg-white p-4 mb-6 rounded-lg shadow-sm">
                    <form @submit.prevent class="flex flex-col sm:flex-row gap-2">
                        <select id="search-type" name="search-type" v-model="searchType"
                            class="rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500 text-black">
                            <option value="query">Cercar a tot arreu</option>
                            <option value="title">Cercar per títol</option>
                            <option value="description">Cercar per descripció</option>
                            <option value="labels">Cercar per etiqueta</option>
                        </select>
                        <input id="search-query" name="search-query" type="text" v-model="searchQuery"
                            placeholder="Cerca els meus articles..."
                            class="text-black flex-1 rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500" />
                    </form>
                </div>

                <!-- Article list with search results or default listing -->
                <div class="overflow-hidden bg-white shadow-sm sm:rounded-lg">
                    <div class="p-6 text-gray-900">
                        <!-- Loading indicator -->
                        <div v-if="isSearching" class="text-center py-4">
                            Cercant articles...
                        </div>

                        <h2 class="text-xl font-semibold mb-4">
                            {{ searchResults ? 'Resultats de cerca:' : 'Els meus articles:' }}
                        </h2>

                        <!-- Articles grid with cards -->
                        <div v-if="(searchResults || props.articles).data && (searchResults || props.articles).data.length"
                            class="overflow-hidden bg-white shadow-sm sm:rounded-lg p-6 text-white text-bold-900">
                            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                                <div v-for="article in (searchResults || props.articles).data" :key="article.id">
                                    <Card :article="article" @view-article="viewArticle" />
                                </div>
                            </div>

                            <!-- Pagination - different component based on search state -->
                            <div class="mt-8 text-gray-900">
                                <AjaxPaginationLinks v-if="searchResults" :paginator="searchResults"
                                    @paginate="handleAjaxPagination" />
                                <PaginationLinks v-else :paginator="props.articles" />
                            </div>
                        </div>

                        <!-- Empty state message -->
                        <div v-else class="text-center py-8">
                            No s'han trobat articles propis.
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </AuthenticatedLayout>
</template>