<script setup>
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';
import InputField from '@/Components/InputField.vue';
import PrimaryButton from '@/Components/PrimaryButton.vue';
import ErrorMessages from '@/Components/ErrorMessages.vue';
import { Head, useForm } from '@inertiajs/vue3';
import { ref, onMounted, watch } from 'vue';
import axios from 'axios';
import ImageUpload from '@/Components/ImageUpload.vue';
import MarkdownIt from 'markdown-it';

const categories = ref([]);
const labelsInput = ref('');
const markdownPreview = ref('');
const showPreview = ref(false);
const imagePreview = ref(null);

// Initialize markdown parser
const md = new MarkdownIt({
    html: false,
    linkify: true,
    typographer: true
});

// Form with article data
const form = useForm({
    title: null,
    description: null,
    labels: null,
    category_id: null,
    image: null,
});

// Update markdown preview when description changes
watch(() => form.description, (newValue) => {
    if (newValue) {
        markdownPreview.value = md.render(newValue);
    } else {
        markdownPreview.value = '';
    }
});

// Load categories when component mounts
onMounted(async () => {
    try {
        const response = await axios.get(route('categories.all'));
        categories.value = response.data;
    } catch (error) {
        console.error('Error fetching categories:', error);
    }
});

// Submit form with processed data
const submitForm = () => {
    if (labelsInput.value) {
        const labelsArray = labelsInput.value.split(',').map(label => label.trim()).filter(label => label !== '');
        form.labels = JSON.stringify(labelsArray);
    }

    form.post(route('article.store'), {
        forceFormData: true
    });
};

// Toggle between edit and preview modes
const togglePreview = () => {
    showPreview.value = !showPreview.value;
};

// Handle image selection and preview
const handleImageUpdate = (file) => {
    form.image = file;

    if (file) {
        const reader = new FileReader();
        reader.onload = e => {
            imagePreview.value = e.target.result;
        };
        reader.readAsDataURL(file);
    } else {
        imagePreview.value = null;
    }
};
</script>

<template>

    <Head title="Nou Article" />

    <AuthenticatedLayout>
        <template #header>
            <h1 class="text-xl font-semibold leading-tight text-black animate-fade-down animate-once">
                Nou Article
            </h1>
        </template>

        <div class="py-12 bg-gradient-to-br from-blue-100 via-purple-200 to-pink-100">
            <div class="mx-auto max-w-7xl sm:px-6 lg:px-8">
                <div class="bg-white p-4 mb-6 rounded-lg shadow-sm">
                    <ErrorMessages :errors="form.errors" />

                    <form @submit.prevent="submitForm" class="grid grid-cols-1 gap-6">
                        <!-- Title field -->
                        <div class="space-y-6">
                            <InputField label="Títol" icon="heading" placeholder="Títol del Article"
                                v-model="form.title" />

                            <!-- Description with markdown editor/preview -->
                            <div class="grid grid-cols-1">
                                <div class="flex justify-between items-center">
                                    <label for="description" class="block text-sm font-medium text-black">
                                        Descripció
                                    </label>
                                    <button type="button" @click="togglePreview"
                                        class="px-3 py-1.5 text-sm bg-gray-800 hover:bg-gray-700 rounded-md text-white font-medium transition-colors">
                                        {{ showPreview ? 'Editar' : 'Previsualitzar' }}
                                    </button>
                                </div>

                                <div v-show="!showPreview" class="relative mt-1 rounded-md">
                                    <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                                        <span class="grid place-content-center text-sm text-slate-400">
                                            <i class="fa-solid fa-newspaper"></i>
                                        </span>
                                    </div>
                                    <textarea id="description" name="description" v-model="form.description" rows="12"
                                        placeholder="Descripció del Article"
                                        class="block w-full rounded-md pr-3 pl-9 text-black border-slate-300 outline-0 focus:ring-1 focus:ring-inset focus:ring-indigo-400 focus:border-indigo-400 placeholder:text-slate-400"></textarea>
                                </div>

                                <div v-show="showPreview"
                                    class="mt-2 p-4 border rounded-md bg-white min-h-[300px] prose max-w-none">
                                    <div v-if="markdownPreview" v-html="markdownPreview" class="text-black"></div>
                                    <div v-else class="text-gray-400 italic">No hi ha contingut per previsualitzar</div>
                                </div>

                                <div class="flex justify-between mt-1 text-xs text-gray-500">
                                    <p>Suporta format Markdown</p>
                                    <a href="https://www.markdownguide.org/cheat-sheet/" target="_blank"
                                        class="text-blue-600 hover:underline">
                                        Guia de Markdown
                                    </a>
                                </div>
                            </div>

                            <!-- Labels/tags input -->
                            <div class="grid grid-cols-1">
                                <div>
                                    <label for="labels" class="block text-sm font-medium text-black">
                                        Etiquetes
                                    </label>

                                    <div class="relative mt-1 rounded-md">
                                        <div
                                            class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                                            <span class="grid place-content-center text-sm text-slate-400">
                                                <i class="fa-solid fa-tags"></i>
                                            </span>
                                        </div>
                                        <input type="text" id="labels" name="labels"
                                            placeholder="Separeu les etiquetes amb comes (ex: tecnologia, intel·ligència artificial)"
                                            v-model="labelsInput"
                                            class="block w-full rounded-md pr-3 pl-9 text-sm dark:text-slate-900 border-slate-300 outline-0 focus:ring-1 focus:ring-inset focus:ring-indigo-400 focus:border-indigo-400 placeholder:text-slate-400" />
                                    </div>
                                    <p class="mt-1 text-xs text-gray-500">Separeu les etiquetes amb comes (,)</p>
                                </div>
                            </div>
                        </div>
                        <div class="space-y-6">
                            <!-- Category dropdown -->
                            <div>
                                <label for="category" class="block text-sm font-medium text-black">
                                    Categories
                                </label>

                                <div class="relative mt-1 rounded-md">
                                    <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                                        <span class="grid place-content-center text-sm text-slate-400">
                                            <i class="fa-solid fa-folder"></i>
                                        </span>
                                    </div>
                                    <select id="category" name="category" v-model="form.category_id"
                                        class="block w-full rounded-md pr-3 pl-9 text-sm dark:text-slate-900 border-slate-300 outline-0 focus:ring-1 focus:ring-inset focus:ring-indigo-400 focus:border-indigo-400">
                                        <option value="" disabled selected>Seleccioneu una categoria</option>
                                        <option v-for="category in categories" :key="category.id" :value="category.id">
                                            {{ category.name }}
                                        </option>
                                    </select>
                                </div>
                            </div>

                            <!-- Image upload -->
                            <div>
                                <label for="image" class="block text-sm font-medium text-slate-700 dark:text-slate-300">
                                    Imatge
                                </label>
                                <div class="mt-1">
                                    <div class="relative">
                                        <input type="file" id="image" name="image"
                                            @change="handleImageUpdate($event.target.files[0])"
                                            accept="image/jpeg,image/png,image/jpg,image/webp"
                                            class="block w-full text-sm text-slate-800 file:mr-4 file:py-2 file:px-4
                                                     file:rounded-md file:border-0 file:text-sm file:font-semibold
                                                     file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100" />
                                    </div>
                                    <div v-if="imagePreview" class="mt-3">
                                        <p class="text-xs text-gray-500 mb-1">Previsualització:</p>
                                        <img :src="imagePreview" class="max-h-48 rounded-md shadow-sm" />
                                    </div>
                                    <p class="mt-1 text-xs text-gray-500">Formats acceptats: JPEG, JPG, PNG, WEBP. Mida
                                        màxima: 3MB</p>
                                </div>
                            </div>
                        </div>

                        <!-- Submit button -->
                        <div>
                            <PrimaryButton>Crear Article</PrimaryButton>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </AuthenticatedLayout>
</template>

<style>
.prose h1 {
    font-size: 1.8em;
    font-weight: bold;
    margin: 0.5em 0;
}

.prose h2 {
    font-size: 1.5em;
    font-weight: bold;
    margin: 0.5em 0;
}

.prose h3 {
    font-size: 1.3em;
    font-weight: bold;
    margin: 0.5em 0;
}

.prose ul {
    list-style-type: disc;
    padding-left: 2em;
}

.prose ol {
    list-style-type: decimal;
    padding-left: 2em;
}

.prose p {
    margin: 0.75em 0;
}

.prose code {
    font-family: monospace;
    background-color: #f0f0f0;
    padding: 0.1em 0.3em;
    border-radius: 3px;
}

.prose pre {
    background-color: #f0f0f0;
    padding: 0.5em;
    border-radius: 5px;
    overflow-x: auto;
}

.prose blockquote {
    border-left: 4px solid #ddd;
    padding-left: 1em;
    margin-left: 0;
    color: #666;
}

.prose a {
    color: #0366d6;
    text-decoration: underline;
}
</style>