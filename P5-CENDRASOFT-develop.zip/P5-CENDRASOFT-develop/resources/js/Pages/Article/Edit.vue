<script setup>
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';
import InputField from '@/Components/InputField.vue';
import TextArea from '@/Components/TextArea.vue';
import PrimaryButton from '@/Components/PrimaryButton.vue';
import ErrorMessages from '@/Components/ErrorMessages.vue';
import { Head, useForm } from '@inertiajs/vue3';
import { ref, onMounted } from 'vue';
import axios from 'axios';

const props = defineProps({
    article: Object,
});

const categories = ref([]);
// Initialize labels input with comma-separated string from array
const labelsInput = ref(props.article.labels ? props.article.labels.join(', ') : '');
// For image preview
const imagePreview = ref(null);

// Initialize form with article data - initialize labels with a default empty array JSON string
const form = useForm({
    title: props.article.title || '',
    description: props.article.description || '',
    labels: JSON.stringify(props.article.labels || []), // Pre-set labels with existing value
    category_id: props.article.category_id || '',
    image: null,
    _method: 'PUT', // Force method to PUT
    _removeImage: false, // New flag to track image removal request
});

// Load categories when component mounts
onMounted(async () => {
    try {
        const response = await axios.get(route('categories.all'));
        categories.value = response.data;

        // Set initial image preview if article has an image
        if (props.article.image) {
            imagePreview.value = `/storage/${props.article.image}`;
        }
    } catch (error) {
        console.error('Error fetching categories:', error);
    }
});

// Handle image selection and preview
const handleImageUpdate = (file) => {
    form.image = file;
    form._removeImage = false; // Reset remove flag when new image is chosen

    if (file) {
        const reader = new FileReader();
        reader.onload = e => {
            imagePreview.value = e.target.result;
        };
        reader.readAsDataURL(file);
    } else {
        // If no new image is selected, restore the original image if available
        imagePreview.value = props.article.image && !form._removeImage ? `/storage/${props.article.image}` : null;
    }
};

// Handle image removal
const handleRemoveImage = () => {
    form.image = null;
    form._removeImage = true;
    imagePreview.value = null;
};

// Handle keeping current image
const handleKeepImage = () => {
    form.image = null;
    form._removeImage = false;
    imagePreview.value = props.article.image ? `/storage/${props.article.image}` : null;
};

// Submit form with processed data
const submitForm = () => {
    // Process the labels input to ensure we have valid data
    const labelsArray = labelsInput.value
        ? labelsInput.value.split(',').map(label => label.trim()).filter(label => label !== '')
        : [];
    form.labels = JSON.stringify(labelsArray);

    // Debug log to check form values before submission
    console.log('Submitting form with values:', {
        title: form.title,
        description: form.description,
        labels: form.labels,
        category_id: form.category_id,
        image: form.image ? 'New image selected' : (form._removeImage ? 'Remove image' : 'Keep current image')
    });

    // Use post with _method: PUT for more consistent behavior with files
    form.post(route('article.update', props.article.id), {
        forceFormData: true, // Required for file uploads
        preserveState: true, // Preserve form state to see validation errors
        onSuccess: () => {
            console.log('Article updated successfully');
        },
        onError: (errors) => {
            console.error('Update failed with errors:', errors);
        }
    });
};
</script>

<template>

    <Head title="Editar Article" />

    <AuthenticatedLayout>
        <template #header>
            <h1 class="text-xl font-semibold leading-tight text-gray-800 animate-fade-down animate-once">
                Editar Article
            </h1>
        </template>

        <div class="py-12 bg-gradient-to-br from-blue-100 via-purple-200 to-pink-100">
            <div class="mx-auto max-w-7xl sm:px-6 lg:px-8">
                <div class="bg-white p-4 mb-6 rounded-lg shadow-sm">
                    <ErrorMessages :errors="form.errors" />

                    <form @submit.prevent="submitForm" class="grid grid-cols-1 gap-6">
                        <div class="space-y-6">
                            <!-- Title field -->
                            <InputField label="Títol" icon="heading" placeholder="Títol del Article"
                                v-model="form.title" />

                            <!-- Description textarea -->
                            <TextArea label="Descripció" icon="newspaper" placeholder="Descripció del Article"
                                v-model="form.description" />

                            <!-- Labels/tags input -->
                            <div class="grid grid-cols-1">
                                <div>
                                    <label for="article-labels" class="block text-sm font-medium text-black">
                                        Etiquetes
                                    </label>

                                    <div class="relative mt-1 rounded-md">
                                        <div
                                            class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                                            <span class="grid place-content-center text-sm text-slate-400">
                                                <i class="fa-solid fa-tags"></i>
                                            </span>
                                        </div>
                                        <input type="text" name="labels" id="article-labels"
                                            placeholder="Separeu les etiquetes amb comes (ex: tecnologia, intel·ligència artificial)"
                                            v-model="labelsInput"
                                            class="block w-full rounded-md pr-3 pl-9 text-sm dark:text-slate-900 border-slate-300 outline-0 focus:ring-1 focus:ring-inset focus:ring-indigo-400 focus:border-indigo-400 placeholder:text-slate-400" />
                                    </div>
                                    <p class="mt-1 text-xs text-gray-500">Separeu les etiquetes amb comes (,)</p>
                                </div>
                            </div>
                        </div>

                        <div class="space-y-6">
                            <!-- Category dropdown -->
                            <div>
                                <label for="article-category" class="block text-sm font-medium text-black">
                                    Categories
                                </label>

                                <div class="relative mt-1 rounded-md">
                                    <div class="pointer-events-none absolute inset-y-0 left-0 flex items-center pl-3">
                                        <span class="grid place-content-center text-sm text-slate-400">
                                            <i class="fa-solid fa-folder"></i>
                                        </span>
                                    </div>
                                    <select name="category" id="article-category" v-model="form.category_id"
                                        class="block w-full rounded-md pr-3 pl-9 text-sm dark:text-slate-900 border-slate-300 outline-0 focus:ring-1 focus:ring-inset focus:ring-indigo-400 focus:border-indigo-400"
                                        aria-label="Selecció de categoria">
                                        <option value="" disabled>Seleccioneu una categoria</option>
                                        <option v-for="category in categories" :key="category.id" :value="category.id">
                                            {{ category.name }}
                                        </option>
                                    </select>
                                </div>
                            </div>

                            <!-- Image upload -->
                            <div>
                                <label for="article-image" class="block text-sm font-medium text-black">
                                    Imatge
                                </label>
                                <div class="mt-1">
                                    <!-- Current image preview and status -->
                                    <div v-if="props.article.image" class="mb-4">
                                        <p class="text-xs text-gray-500 mb-1">Imatge actual:</p>

                                        <!-- Current image preview -->
                                        <div v-if="imagePreview" class="mb-2">
                                            <img :src="imagePreview" class="max-h-48 rounded-md shadow-sm"
                                                alt="Previsualització de la imatge" />
                                        </div>

                                        <!-- Status message based on current state -->
                                        <div v-if="!form._removeImage && !form.image"
                                            class="text-sm text-green-600 py-1">
                                            <i class="fa-solid fa-check-circle mr-1"></i> Es mantindrà aquesta imatge
                                        </div>
                                        <div v-else-if="form.image" class="text-sm text-blue-600 py-1">
                                            <i class="fa-solid fa-arrow-right-arrow-left mr-1"></i> Es canviarà per la nova imatge
                                        </div>
                                        <div v-else-if="form._removeImage" class="text-sm text-red-600 py-1">
                                            <i class="fa-solid fa-trash-alt mr-1"></i> S'eliminarà la imatge
                                        </div>

                                        <!-- Image action buttons -->
                                        <div class="flex gap-2 mt-2">
                                            <button type="button" v-if="!form._removeImage" @click="handleRemoveImage"
                                                class="text-xs py-1 px-2 text-red-600 border border-red-600 rounded hover:bg-red-50">
                                                Eliminar imatge
                                            </button>
                                            <button type="button" v-if="form._removeImage || form.image"
                                                @click="handleKeepImage"
                                                class="text-xs py-1 px-2 text-green-600 border border-green-600 rounded hover:bg-green-50">
                                                Mantenir imatge actual
                                            </button>
                                        </div>
                                    </div>

                                    <!-- File input -->
                                    <div class="relative mt-2">
                                        <input type="file" id="article-image" name="image"
                                            @change="handleImageUpdate($event.target.files[0])"
                                            accept="image/jpeg,image/png,image/jpg,image/webp" 
                                            class="block w-full text-sm text-slate-800 file:mr-4 file:py-2 file:px-4
                                                file:rounded-md file:border-0 file:text-sm file:font-semibold
                                                file:bg-indigo-50 file:text-indigo-700 hover:file:bg-indigo-100"
                                            aria-label="Selecciona una imatge per l'article" />
                                    </div>
                                    <p class="mt-1 text-xs text-gray-500">Formats acceptats: JPEG, JPG, PNG, WEBP. Mida màxima: 3MB</p>
                                    <p v-if="props.article.image && !form.image && !form._removeImage" class="mt-1 text-xs text-blue-600">
                                        <i class="fa-solid fa-info-circle mr-1"></i> Es mantindrà la imatge actual si no en selecciones cap de nova
                                    </p>
                                </div>
                            </div>
                        </div>

                        <!-- Submit button -->
                        <div>
                            <PrimaryButton type="submit">Actualitzar Article</PrimaryButton>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </AuthenticatedLayout>
</template>