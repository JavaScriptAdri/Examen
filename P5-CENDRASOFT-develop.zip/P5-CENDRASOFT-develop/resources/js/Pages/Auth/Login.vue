<script setup>
import Checkbox from '@/Components/Checkbox.vue';
import GuestLayout from '@/Layouts/GuestLayout.vue';
import InputError from '@/Components/InputError.vue';
import InputLabel from '@/Components/InputLabel.vue';
import PrimaryButton from '@/Components/PrimaryButton.vue';
import TextInput from '@/Components/TextInput.vue';
import { Head, Link, useForm } from '@inertiajs/vue3';

defineProps({
    canResetPassword: {
        type: Boolean,
    },
    status: {
        type: String,
    },
});

const form = useForm({
    email: '',
    password: '',
    remember: false,
});

const submit = () => {
    form.post(route('login'), {
        onFinish: () => form.reset('password'),
    });
};
const redirectToGoogleLogin = () => {
    window.location.href = '/login-google';
};

const redirectToGithubLogin = () => {
    window.location.href = '/login-github';
};
</script>

<template>
    <GuestLayout class="bg-gradient-to-bl from-fuchsia-700  via-indigo-700 to-fuchsia-700">
        <Head title="Iniciar Sessió" />

        <div v-if="status" class="mb-1 text-sm font-medium text-green-600">
            {{ status }}
        </div>

        <form @submit.prevent="submit" class="" >
            <div>
                <InputLabel class="bg-gradient-to-r from-purple-500 to-pink-500 bg-clip-text font-bold text-transparent text-xl" 
                    for="email" 
                    value="Correu electrònic" />

                <TextInput
                    id="email"
                    type="email"
                    class="mt-1 block w-full text-black"
                    v-model="form.email"
                    required
                    autofocus
                    autocomplete="username"
                />

                <InputError class="mt-2" :message="form.errors.email" />
            </div>

            <div class="mt-4">
                <InputLabel class="text-black bg-gradient-to-r from-purple-500 to-pink-500 font-bold bg-clip-text text-transparent text-xl" 
                    for="password" 
                    value="Contrasenya" />

                <TextInput
                    id="password"
                    type="password"
                    class="mt-1 block w-full text-black"
                    v-model="form.password"
                    required
                    autocomplete="current-password"
                />

                <InputError class="mt-2" :message="form.errors.password" />
            </div>

            <div class="mt-4 block">
                <label class="flex items-center">
                    <Checkbox name="remember" v-model:checked="form.remember" />
                    <span class="ms-2 text-sm text-gray-600"
                        >Recorda'm</span
                    >
                </label>
            </div>

            <div class="mt-4 flex items-center justify-end">
                <Link
                    v-if="canResetPassword"
                    :href="route('password.request')"
                    class="rounded-md text-sm text-gray-600 underline hover:text-gray-900 focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:ring-offset-2"
                >
                    Has Oblidat la teva contrasenya?
                </Link>

                <PrimaryButton
                    class="ms-4 bg-gradient-to-r from-purple-500 to-pink-500 font-bold"
                    :class="{ 'opacity-25': form.processing }"
                    :disabled="form.processing"
                >
                    Iniciar Sessió
                </PrimaryButton>
            </div>
        </form>
        <div class="mt-6 flex justify-center">
            <button
                @click="redirectToGoogleLogin"
                 class="flex items-center justify-center rounded-md w-full px-4 py-2 text-sm  text-white bg-gradient-to-r from-purple-500 to-pink-500 font-bold"
            >
                <svg class="w-6 h-6 mr-2 " xmlns="http://www.w3.org/2000/svg" viewBox="0 0 48 48">
                    <path fill="#EA4335" d="M24 9.5c3.5 0 6.6 1.3 9 3.4l6.7-6.7C35.6 2.5 30.1 0 24 0 14.8 0 7.1 5.8 3.7 14.1l7.8 6.1C13.2 13.2 18.2 9.5 24 9.5z"/>
                    <path fill="#34A853" d="M46.5 24c0-1.6-.2-3.2-.5-4.7H24v9h12.7c-1.1 3.6-3.5 6.6-6.7 8.6l7.8 6.1c4.5-4.1 7.7-10.2 7.7-18z"/>
                    <path fill="#4A90E2" d="M10.5 28.2c-1.1-3.6-1.1-7.4 0-11l-7.8-6.1C.7 15.8 0 19.8 0 24s.7 8.2 2.7 11.9l7.8-6.1z"/>
                    <path fill="#FBBC05" d="M24 48c6.1 0 11.6-2.1 15.5-5.7l-7.8-6.1c-2.2 1.5-5 2.4-7.7 2.4-5.8 0-10.8-3.7-12.6-8.9l-7.8 6.1C7.1 42.2 14.8 48 24 48z"/>
                </svg>
                Inicia Sessió amb Google
            </button>
        </div>
        <div class="mt-2 flex justify-center">
            <button
                @click="redirectToGithubLogin"
                class="flex items-center justify-center rounded-md w-full px-4 py-2 text-sm text-white bg-gradient-to-r from-purple-500 to-pink-500 font-bold"
            >
                <svg class="w-6 h-6 mr-2" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24">
                    <path fill="white" d="M12 0c-6.626 0-12 5.373-12 12 0 5.302 3.438 9.8 8.207 11.387.599.111.793-.261.793-.577v-2.234c-3.338.726-4.033-1.416-4.033-1.416-.546-1.387-1.333-1.756-1.333-1.756-1.089-.745.083-.729.083-.729 1.205.084 1.839 1.237 1.839 1.237 1.07 1.834 2.807 1.304 3.492.997.107-.775.418-1.305.762-1.604-2.665-.305-5.467-1.334-5.467-5.931 0-1.311.469-2.381 1.236-3.221-.124-.303-.535-1.524.117-3.176 0 0 1.008-.322 3.301 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.291-1.552 3.297-1.23 3.297-1.23.653 1.653.242 2.874.118 3.176.77.84 1.235 1.911 1.235 3.221 0 4.609-2.807 5.624-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .319.192.694.801.576 4.765-1.589 8.199-6.086 8.199-11.386 0-6.627-5.373-12-12-12z"/>
                </svg>
                Inicia Sessió amb GitHub
            </button>
        </div>
    </GuestLayout>
</template>
