<script setup>
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';
import { Head, useForm } from '@inertiajs/vue3';
import InputError from '@/Components/InputError.vue';
import PrimaryButton from '@/Components/PrimaryButton.vue';
import Footer from "@/Components/Footer.vue";

const props = defineProps({
    categories: Array,
    message: String,
});

// Form for adding new category
const form = useForm({
    name: '',
});

// Create category and reset form on success
const submit = () => {
    form.post('/categories', {
        onSuccess: () => form.reset(),
    });
};

// Delete category with confirmation
const deleteCategory = (id) => {
    if (confirm('Estàs segur que vols eliminar aquesta categoria?')) {
        form.delete(`/categories/${id}`);
    }
};
</script>

<template>
    <Head title="Categories" />

    <AuthenticatedLayout>
        <template #header>
            <h2 class="text-xl font-semibold leading-tight text-black animate-fade-down animate-once">
                Categories
            </h2>
        </template>

        <div class="py-12 bg-gradient-to-br from-blue-100 via-purple-200 to-pink-100">
            <div class="mx-auto max-w-7xl sm:px-6 lg:px-8 space-y-6">
                <!-- Flash message -->
                <div v-if="message" 
                    class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative" 
                    role="alert">
                    <span class="block sm:inline">{{ message }}</span>
                </div>

                <!-- Category creation form -->
                <div class="p-6 bg-white shadow-sm sm:rounded-lg">
                    <h3 class="text-lg font-semibold mb-4 bg-gradient-to-r from-purple-500 to-pink-500 bg-clip-text text-transparent">
                        Crear Nova Categoria
                    </h3>
                    
                    <form @submit.prevent="submit" class="space-y-4">
                        <div>
                            <label for="name" class="block text-sm font-medium text-gray-700">Nom de la categoria</label>
                            <div class="mt-1 relative rounded-md shadow-sm">
                                <div class="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                    <i class="fas fa-folder text-gray-400"></i>
                                </div>
                                <input
                                    type="text"
                                    id="name"
                                    v-model="form.name"
                                    class="block w-full pl-10 pr-3 py-2 border border-gray-300 rounded-md text-black focus:outline-none focus:ring-1 focus:ring-indigo-500 focus:border-indigo-500"
                                    placeholder="Introdueix el nom de la categoria"
                                    required
                                />
                            </div>
                            <InputError class="mt-2" :message="form.errors.name" />
                        </div>

                        <div class="flex justify-end">
                            <PrimaryButton
                                :class="{ 'opacity-25': form.processing }"
                                :disabled="form.processing"
                                class="bg-gradient-to-r from-purple-500 to-pink-500"
                            >
                                Crear Categoria
                            </PrimaryButton>
                        </div>
                    </form>
                </div>

                <!-- Categories list -->
                <div class="bg-white shadow-sm sm:rounded-lg">
                    <div class="p-6">
                        <h3 class="text-lg font-semibold mb-4 bg-gradient-to-r from-purple-500 to-pink-500 bg-clip-text text-transparent">
                            Les Teves Categories
                        </h3>
                        
                        <div v-if="categories && categories.length > 0" class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                            <div v-for="category in categories" :key="category.id" 
                                class="p-4 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-lg shadow flex justify-between items-center">
                                <span class="font-medium">{{ category.name }}</span>
                                <button 
                                    @click="deleteCategory(category.id)"
                                    class="text-white hover:text-red-200 transition-colors"
                                >
                                    <i class="fas fa-trash"></i>
                                </button>
                            </div>
                        </div>
                        <div v-else class="text-gray-500 text-center py-4">
                            No hi ha categories creades encara
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </AuthenticatedLayout>
    <Footer />
</template>
