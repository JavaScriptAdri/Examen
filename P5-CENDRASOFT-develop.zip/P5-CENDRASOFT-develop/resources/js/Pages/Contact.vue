<script setup>
import { Head } from '@inertiajs/vue3';
import Footer from '@/Components/Footer.vue';
import { ref } from 'vue';
import { useForm } from '@inertiajs/vue3';

// Contact form with validation
const form = useForm({
  name: '',
  email: '',
  message: ''
});

// Handle form submission
const submitForm = () => {
  form.post('/send-contact', {
    onSuccess: () => {
      alert('Missatge enviat correctament!');
      form.reset();
    },
    onError: () => {
      alert('Hi ha hagut un error en enviar el missatge.');
    }
  });
};
</script>

<template>
  <div>
    <Head title="Contacte" />
   
    <!-- Contact form section -->
    <section class="py-16 bg-gradient-to-br from-blue-100 via-purple-200 to-pink-100">
      <div class="max-w-4xl mx-auto px-4">
        <h1 class="text-4xl font-bold text-center text-gray-800 mb-6">Contacte</h1>
        <p class="text-lg text-gray-800 mb-4 text-center">
          Si tens qualsevol dubte o consulta, no dubtis a posar-te en contacte amb nosaltres mitjançant el següent formulari.
        </p>

        <div class="bg-white p-6 rounded-lg shadow-md">
          <form @submit.prevent="submitForm">
            <div class="mb-4">
              <label for="name" class="block text-gray-800 font-semibold mb-2">Nom complet:</label>
              <input v-model="form.name" type="text" id="name" class="w-full border rounded-lg px-4 py-2 text-gray-800" required>
            </div>

            <div class="mb-4">
              <label for="email" class="block text-gray-800 font-semibold mb-2">Correu electrònic:</label>
              <input v-model="form.email" type="email" id="email" class="w-full border rounded-lg px-4 py-2 text-gray-800" required>
            </div>

            <div class="mb-4">
              <label for="message" class="block text-gray-800 font-semibold mb-2">Missatge:</label>
              <textarea v-model="form.message" id="message" rows="5" class="w-full border rounded-lg px-4 py-2 text-gray-800" required></textarea>
            </div>

            <button type="submit" class="bg-blue-800 text-white rounded-lg px-4 py-2 hover:bg-blue-600">
              Enviar missatge
            </button>
          </form>
        </div>

        <!-- Contact information -->
        <div class="mt-10 text-center">
          <h2 class="text-2xl font-semibold text-gray-800 mb-4">Informació de Contacte</h2>
          <p class="text-base text-gray-800">Adreça: Carrer Exemple, 123, Figueres</p>
          <p class="text-base text-gray-800">Telèfon: +34 123 456 789</p>
          <p class="text-base text-gray-800">Correu electrònic: Cendrasoft@info.com</p>
        </div>
      </div>
    </section>

    <Footer />
  </div>
</template>

