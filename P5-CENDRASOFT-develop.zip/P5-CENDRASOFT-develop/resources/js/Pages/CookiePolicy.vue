<script setup>
import { Head } from '@inertiajs/vue3';
import Footer from '@/Components/Footer.vue';
</script>

<template>
  <div>
    <Head title="Política de Cookies" />
   
    <!-- Cookie policy content -->
    <section class="py-16 bg-gradient-to-br from-blue-100 via-purple-200 to-pink-100">
      <div class="max-w-4xl mx-auto px-4">
        <h1 class="text-4xl font-bold text-center text-gray-800 mb-6">Política de Cookies</h1>
        <p class="text-lg text-gray-800 mb-4">
          Aquesta pàgina web utilitza cookies per millorar l'experiència de navegació i oferir serveis personalitzats. En continuar navegant, acceptes l'ús de les cookies d'acord amb aquesta política.
        </p>

        <div class="bg-white p-6 rounded-lg shadow-md">
          <h2 class="text-2xl font-semibold text-gray-800 mb-4">Què són les cookies?</h2>
          <p class="text-base text-gray-700 mb-4">
            Les cookies són petits arxius de text que s'emmagatzemen al dispositiu de l'usuari quan visita un lloc web. Serveixen per recordar preferències de navegació i millorar l'experiència de l'usuari.
          </p>

          <h2 class="text-2xl font-semibold text-gray-800 mb-4">Tipus de Cookies que Utilitzem</h2>
          <ul class="list-disc pl-6 text-gray-700 mb-4">
            <li><strong>Cookies Necessàries:</strong> Essencials per al funcionament correcte de la pàgina web.</li>
            <li><strong>Cookies de Rendiment:</strong> Recullen informació sobre com els usuaris utilitzen la web per ajudar a millorar el seu funcionament.</li>
            <li><strong>Cookies de Funcionalitat:</strong> Permeten recordar les preferències de l'usuari (com l'idioma o la ubicació).</li>
            <li><strong>Cookies de Publicitat:</strong> Utilitzades per mostrar anuncis personalitzats segons els interessos de l'usuari.</li>
          </ul>

          <h2 class="text-2xl font-semibold text-gray-800 mb-4">Com Gestionar les Cookies?</h2>
          <p class="text-base text-gray-700 mb-4">
            Pots gestionar i eliminar les cookies des de la configuració del teu navegador. Tingues en compte que, si desactives algunes cookies, és possible que algunes funcionalitats de la pàgina no estiguin disponibles.
          </p>

          <h2 class="text-2xl font-semibold text-gray-800 mb-4">Canvis en la Política de Cookies</h2>
          <p class="text-base text-gray-700 mb-4">
            Aquesta política de cookies pot ser actualitzada periòdicament per adaptar-se als canvis legals o tècnics. Es recomana revisar-la regularment per estar informat sobre l'ús de les cookies.
          </p>
        </div>
      </div>
    </section>
    
    <Footer />
  </div>
</template>
