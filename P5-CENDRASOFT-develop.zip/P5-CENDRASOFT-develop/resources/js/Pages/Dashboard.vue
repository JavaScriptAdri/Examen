<script setup>
import AuthenticatedLayout from '@/Layouts/AuthenticatedLayout.vue';
import { Head, Link } from '@inertiajs/vue3';
import Footer from "@/Components/Footer.vue";
</script>

<template>
    <Head title="Inici" />

    <AuthenticatedLayout>
        <template #header>
            <h2 class="text-xl font-semibold leading-tight text-black animate-fade-down animate-once">
                Benvingut/da a CendraSoft
            </h2>
        </template>

        <div class="py-12 bg-gradient-to-br from-blue-100 via-purple-200 to-pink-100 min-h-screen">
            <div class="mx-auto max-w-7xl px-4 sm:px-6 lg:px-8">
                <!-- Welcome section with quick action cards -->
                <div class="bg-white rounded-lg shadow-lg p-8 mb-8">
                    <h3 class="text-2xl font-bold mb-4 bg-gradient-to-r from-purple-500 to-pink-500 bg-clip-text text-transparent">
                        Comença la teva aventura
                    </h3>
                    <p class="text-gray-700 mb-6">
                        Benvingut/da a la teva plataforma personal d'articles. Aquí podràs crear, gestionar i compartir els teus coneixements amb la comunitat.
                    </p>
                    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
                        <!-- Create article card -->
                        <Link href="/article/create" 
                            class="bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-lg p-6 shadow-md hover:shadow-lg transition-shadow">
                            <div class="flex items-center mb-4">
                                <i class="fas fa-pencil-alt text-2xl"></i>
                                <h4 class="text-lg font-semibold ml-3">Crea un Article</h4>
                            </div>
                            <p class="text-sm opacity-90">
                                Comparteix els teus coneixements creant un nou article
                            </p>
                        </Link>

                        <!-- View articles card -->
                        <Link href="/article" 
                            class="bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-lg p-6 shadow-md hover:shadow-lg transition-shadow">
                            <div class="flex items-center mb-4">
                                <i class="fas fa-book text-2xl"></i>
                                <h4 class="text-lg font-semibold ml-3">Els meus Articles</h4>
                            </div>
                            <p class="text-sm opacity-90">
                                Accedeix i gestiona els teus articles publicats
                            </p>
                        </Link>

                        <!-- Categories card -->
                        <Link href="/categories" 
                            class="bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-lg p-6 shadow-md hover:shadow-lg transition-shadow">
                            <div class="flex items-center mb-4">
                                <i class="fas fa-folder text-2xl"></i>
                                <h4 class="text-lg font-semibold ml-3">Categories</h4>
                            </div>
                            <p class="text-sm opacity-90">
                                Explora i organitza els articles per categories
                            </p>
                        </Link>
                    </div>
                </div>

                <!-- Tips and features section -->
                <div class="grid grid-cols-1 md:grid-cols-2 gap-8">
                    <!-- Writing tips card -->
                    <div class="bg-white rounded-lg shadow-lg p-6">
                        <h3 class="text-xl font-semibold mb-4 bg-gradient-to-r from-purple-500 to-pink-500 bg-clip-text text-transparent">
                            Consells per escriure
                        </h3>
                        <ul class="space-y-3 text-gray-700">
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-500 mt-1 mr-2"></i>
                                Utilitza títols clars i descriptius
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-500 mt-1 mr-2"></i>
                                Organitza el contingut amb subtítols
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-500 mt-1 mr-2"></i>
                                Afegeix etiquetes rellevants
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-check text-green-500 mt-1 mr-2"></i>
                                Utilitza format Markdown per millorar la presentació
                            </li>
                        </ul>
                    </div>

                    <!-- Features highlight card -->
                    <div class="bg-white rounded-lg shadow-lg p-6">
                        <h3 class="text-xl font-semibold mb-4 bg-gradient-to-r from-purple-500 to-pink-500 bg-clip-text text-transparent">
                            Funcionalitats destacades
                        </h3>
                        <ul class="space-y-3 text-gray-700">
                            <li class="flex items-start">
                                <i class="fas fa-star text-yellow-500 mt-1 mr-2"></i>
                                Editor Markdown amb previsualització
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-star text-yellow-500 mt-1 mr-2"></i>
                                Organització per categories
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-star text-yellow-500 mt-1 mr-2"></i>
                                Sistema d'etiquetes personalitzat
                            </li>
                            <li class="flex items-start">
                                <i class="fas fa-star text-yellow-500 mt-1 mr-2"></i>
                                Càrrega d'imatges pels articles
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </AuthenticatedLayout>
    <Footer />
</template>
