<script setup>
import { ref } from 'vue';
import { Head } from '@inertiajs/vue3';
import Footer from "@/Components/Footer.vue";

// Control popup state
const showPopup = ref(false);
const selectedDeveloper = ref({});

// Open popup with selected developer
const openPopup = (developer) => {
  selectedDeveloper.value = developer;
  showPopup.value = true;
};

const closePopup = () => {
  showPopup.value = false;
  selectedDeveloper.value = {};
};

const developers = [
  {
    name: 'Adria',
    image: 'https://i.pinimg.com/originals/28/27/77/2827771068d374a49d2c0fa49d30967d.gif',
    description: 'Deïtat del desenvolupament Full-Stack, mestre de cada línia de codi i arquitecte de solucions impecables. La meva passió per l\'eficiència i el codi net transforma idees en experiències digitals perfectes.'
  },
  {
    name: 'Alex',
    image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ88-y-9RcnHJuiWj9CV2k2B1vM7ilzZ3WM2w&s',
    description: 'Back-end Developer amb una passió inigualable per Rutes i Permisos. Mestre del control i el accés, creo arquitectures tan impecables que funcionen amb una precisió absoluta i una eficàcia impecable.'
  }
];
</script>

<template>
  <Head title="Desenvolupadors" />
  <div class="min-h-screen flex flex-col">
    <div class="bg-gradient-to-br from-blue-100 via-purple-200 to-pink-100 min-h-screen flex flex-col items-center justify-center py-12">
      <h1 class="text-4xl font-bold text-gray-800 text-center mb-8">Coneix l'Equip de Desenvolupadors</h1>
      <div class="grid grid-cols-1 sm:grid-cols-2 gap-8 max-w-5xl px-4">
        <!-- Developer Cards -->
        <div
          v-for="(developer, index) in developers"
          :key="index"
          class="flex flex-col items-center bg-white rounded-lg shadow-lg p-6 cursor-pointer transition-transform hover:scale-105"
          @click="openPopup(developer)"
        >
          <img
            :src="developer.image"
            :alt="'Avatar ' + (index + 1)"
            class="w-24 h-24 rounded-full mb-4 object-cover"
          />
          <h2 class="text-xl font-semibold text-gray-800">{{ developer.name }}</h2>
          <p class="text-center text-gray-700">{{ developer.description }}</p>
        </div>
      </div>
    </div>

    <!-- Pop-up -->
    <transition name="fade">
      <div
        v-if="showPopup"
        class="fixed inset-0 bg-black bg-opacity-75 flex items-center justify-center z-50"
        @click.self="closePopup"
      >
        <div class="bg-white rounded-lg shadow-lg p-8 max-w-md w-full m-4">
          <img
            :src="selectedDeveloper.image"
            alt="Avatar"
            class="w-32 h-32 rounded-full mb-4 mx-auto object-cover"
          />
          <h2 class="text-2xl font-semibold text-center text-gray-800">{{ selectedDeveloper.name }}</h2>
          <p class="text-center text-gray-700 mt-4">{{ selectedDeveloper.description }}</p>
          <button
            @click="closePopup"
            class="block bg-red-600 text-white rounded-full px-4 py-2 mt-6 mx-auto hover:bg-red-700 focus:outline-none"
          >
            Tancar
          </button>
        </div>
      </div>
    </transition>

    <Footer />
  </div>
</template>

<style>
.fade-enter-active,
.fade-leave-active {
  transition: opacity 0.3s;
}
.fade-enter-from,
.fade-leave-to {
  opacity: 0;
}
</style>


