<script setup>
import { Head, Link } from '@inertiajs/vue3';
import { ref, onMounted } from 'vue';
import MarkdownIt from 'markdown-it';
import Footer from '@/Components/Footer.vue';

const props = defineProps({
    article: Object,
    canLogin: Boolean,
    canRegister: Boolean,
});

// Initialize markdown parser and rendered content
const renderedDescription = ref('');
const md = new MarkdownIt({
    html: false,
    linkify: true,
    typographer: true
});

// Render markdown content when component mounts
onMounted(() => {
    if (props.article.description) {
        renderedDescription.value = md.render(props.article.description);
    }
});
</script>

<template>
    <Head :title="article.title" />
    
    <div class="bg-gradient-to-br from-blue-100 via-purple-200 to-pink-100 min-h-screen text-gray-800">
        <!-- Header with navigation -->
        <header class="bg-gradient-to-r from-purple-500 to-pink-500 text-white py-6 shadow-lg">
            <div class="container mx-auto flex justify-between items-center px-6">
                <Link href="/">
                    <h1 class="relative w-fit h-auto py-4 flex bg-white items-center bg-clip-text text-4xl font-extrabold text-transparent text-center">
                        Benvinguts a la nostra web
                    </h1>
                </Link>
                <nav class="flex space-x-4">
                    <Link :href="route('login')"
                        class="bg-white text-purple-600 font-bold rounded-md px-4 py-2 text-sm shadow-md hover:bg-gray-100">
                        Iniciar Sessió
                    </Link>
                    <Link :href="route('register')"
                        class="bg-white text-purple-600 font-bold rounded-md px-4 py-2 text-sm shadow-md hover:bg-gray-100">
                        Registrar-se
                    </Link>
                </nav>
            </div>
        </header>

        <!-- Article content -->
        <div class="py-12">
            <div class="mx-auto max-w-7xl sm:px-6 lg:px-8">
                <div class="overflow-hidden bg-white shadow-sm sm:rounded-lg">
                    <div class="p-6 text-gray-900">
                        <!-- Article featured image -->
                        <div v-if="article.image" class="mb-6">
                            <img :src="`/storage/${article.image}`" :alt="article.title"
                                class="w-full rounded-md max-h-96 object-cover shadow-md" />
                        </div>

                        <h2 class="text-2xl font-bold mb-4">{{ article.title }}</h2>

                        <!-- Rendered markdown content -->
                        <div class="prose max-w-none mb-6" v-html="renderedDescription"></div>

                        <!-- Article metadata -->
                        <p class="text-sm text-gray-800 mb-4">Created on: {{ new Date(article.created_at).toLocaleDateString() }}</p>
                        <p class="text-sm text-gray-800 mb-4">Author: {{ article.user.name }}</p>
                        
                        <!-- Article tags/labels -->
                        <div v-if="article.labels" class="flex flex-wrap gap-2 mb-8">
                            <span v-for="label in article.labels" :key="label"
                                class="bg-blue-800 text-white px-3 py-1 rounded-full">
                                {{ label }}
                            </span>
                        </div>
                        
                        <!-- Back button -->
                        <div class="mt-8">
                            <Link href="/" class="px-4 py-2 bg-gradient-to-r from-purple-500 to-pink-500 text-white rounded-md hover:opacity-90 transition-opacity">
                                Tornar enrere
                            </Link>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <Footer />
    </div>
</template>

<style>
.prose h1 { font-size: 1.8em; font-weight: bold; margin: 0.5em 0; }
.prose h2 { font-size: 1.5em; font-weight: bold; margin: 0.5em 0; }
.prose h3 { font-size: 1.3em; font-weight: bold; margin: 0.5em 0; }
.prose ul { list-style-type: disc; padding-left: 2em; }
.prose ol { list-style-type: decimal; padding-left: 2em; }
.prose p { margin: 0.75em 0; }
.prose code { font-family: monospace; background-color: #f0f0f0; padding: 0.1em 0.3em; border-radius: 3px; }
.prose pre { background-color: #f0f0f0; padding: 0.5em; border-radius: 5px; overflow-x: auto; }
.prose blockquote { border-left: 4px solid #ddd; padding-left: 1em; margin-left: 0; color: #666; }
.prose a { color: #0366d6; text-decoration: underline; }
</style>