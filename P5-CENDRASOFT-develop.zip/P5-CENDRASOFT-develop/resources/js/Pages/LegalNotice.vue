<script setup>
import { Head } from '@inertiajs/vue3';
import Footer from '@/Components/Footer.vue';
</script>

<template>
  <div>
    <Head title="Avisos Legals" />

    <!-- Legal notices section -->
    <section class="py-16 bg-gradient-to-br from-blue-100 via-purple-200 to-pink-100">
      <div class="max-w-4xl mx-auto px-4">
        <h1 class="text-4xl font-bold text-center text-gray-800 mb-6">Avisos Legals</h1>
        <p class="text-lg text-gray-800 mb-4">
          Aquí trobaràs els avisos legals relacionats amb l'ús de la plataforma.
        </p>
        <div class="bg-white p-6 rounded-lg shadow-md">
          <h2 class="text-2xl font-semibold text-gray-800 mb-4">Termes i Condicions</h2>
          <p class="text-base text-gray-700 mb-4">
            Els termes i condicions que regeixen l'ús d'aquesta plataforma estan subjectes a les normatives locals i
            internacionals sobre privacitat i protecció de dades.
          </p>
          <h2 class="text-2xl font-semibold text-gray-800 mb-4">Política de Privacitat</h2>
          <p class="text-base text-gray-700 mb-4">
            La política de privacitat descriu com es recullen, emmagatzemen i utilitzen les teves dades personals en
            interactuar amb la nostra plataforma.
          </p>
          <h2 class="text-2xl font-semibold text-gray-800 mb-4">Ús de Cookies</h2>
          <p class="text-base text-gray-700 mb-4">
            Aquest lloc web utilitza cookies per millorar l'experiència de l'usuari. Per més detalls, consulta la nostra
            política de cookies.
          </p>
        </div>
      </div>
    </section>
    <Footer />
  </div>
</template>