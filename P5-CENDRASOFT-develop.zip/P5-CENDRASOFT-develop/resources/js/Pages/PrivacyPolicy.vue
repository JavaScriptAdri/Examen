<script setup>
import { Head } from '@inertiajs/vue3';
import Footer from '@/Components/Footer.vue';
</script>

<template>
  <div>
    <Head title="Política de Privacitat" />

    <section class="py-16 bg-gradient-to-br from-blue-100 via-purple-200 to-pink-100">
      <div class="max-w-4xl mx-auto px-4">
        <h1 class="text-4xl font-bold text-center text-gray-800 mb-6">Política de Privacitat</h1>
        <p class="text-lg text-gray-800 mb-4">
          La teva privacitat és important per a nosaltres. Aquesta política de privacitat descriu com recollim, utilitzem i protegim la teva informació personal.
        </p>

        <div class="bg-white p-6 rounded-lg shadow-md">
          <h2 class="text-2xl font-semibold text-gray-800 mb-4">1. Informació que Recollim</h2>
          <p class="text-base text-gray-700 mb-4">
            Recollim informació personal quan interactues amb la nostra plataforma. Aquesta informació pot incloure:
          </p>
          <ul class="list-disc pl-6 text-gray-700 mb-4">
            <li>Informació de contacte (nom, correu electrònic, número de telèfon).</li>
            <li>Informació de navegació (adreça IP, tipus de navegador, pàgines visitades).</li>
            <li>Qualsevol altra informació que proporcionis voluntàriament.</li>
          </ul>

          <h2 class="text-2xl font-semibold text-gray-800 mb-4">2. Com Utilitzem la teva Informació</h2>
          <p class="text-base text-gray-700 mb-4">
            Utilitzem la informació recollida per a diversos propòsits, com ara:
          </p>
          <ul class="list-disc pl-6 text-gray-700 mb-4">
            <li>Proporcionar i millorar els nostres serveis.</li>
            <li>Respondre a les teves consultes o sol·licituds.</li>
            <li>Enviar notificacions o actualitzacions importants.</li>
            <li>Personalitzar l'experiència de l'usuari.</li>
          </ul>

          <h2 class="text-2xl font-semibold text-gray-800 mb-4">3. Compartició de la teva Informació</h2>
          <p class="text-base text-gray-700 mb-4">
            No venem ni compartim la teva informació personal amb tercers, excepte en els casos següents:
          </p>
          <ul class="list-disc pl-6 text-gray-700 mb-4">
            <li>Amb proveïdors de serveis de confiança que ajuden en les operacions de la web.</li>
            <li>Per complir amb obligacions legals o respondre a sol·licituds legals.</li>
          </ul>

          <h2 class="text-2xl font-semibold text-gray-800 mb-4">4. Protecció de la teva Informació</h2>
          <p class="text-base text-gray-700 mb-4">
            Implementem mesures de seguretat tècniques i organitzatives per protegir la teva informació personal contra pèrdua, robatori o accés no autoritzat.
          </p>

          <h2 class="text-2xl font-semibold text-gray-800 mb-4">5. Drets de l'Usuari</h2>
          <p class="text-base text-gray-700 mb-4">
            Tens dret a accedir, rectificar o eliminar la teva informació personal. També pots oposar-te al tractament de les teves dades o sol·licitar la portabilitat de les mateixes.
          </p>

          <h2 class="text-2xl font-semibold text-gray-800 mb-4">6. Canvis en la Política de Privacitat</h2>
          <p class="text-base text-gray-700 mb-4">
            Aquesta política de privacitat pot ser modificada per reflectir canvis en les pràctiques de recollida d'informació o en la legislació aplicable. T'informarem de qualsevol canvi important.
          </p>

          <h2 class="text-2xl font-semibold text-gray-800 mb-4">7. Contacte</h2>
          <p class="text-base text-gray-700 mb-4">
            Si tens preguntes sobre aquesta política de privacitat o sobre com gestionem la teva informació personal, pots posar-te en contacte amb nosaltres a través del nostre correu electrònic de suport.
          </p>
        </div>
      </div>
    </section>

    <Footer />
  </div>
</template>

