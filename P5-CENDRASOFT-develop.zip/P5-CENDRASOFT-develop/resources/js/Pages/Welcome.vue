<script setup>
import { Head, Link, router, usePage } from '@inertiajs/vue3';
import Card from '@/Components/Card.vue';
import PaginationLinks from '@/Components/PaginationLinks.vue';
import AjaxPaginationLinks from '@/Components/AjaxPaginationLinks.vue';
import Footer from '@/Components/Footer.vue';
import CookieBanner from '@/Components/CookieBanner.vue';
import { ref, watch } from 'vue';
import axios from 'axios';

const props = defineProps({
    canLogin: {
        type: Boolean,
    },
    canRegister: {
        type: Boolean,
    },
    laravelVersion: {
        type: String,
        required: true,
    },
    phpVersion: {
        type: String,
        required: true,
    },
    articles: {
        type: Object,
        default: () => ({ data: [] }),
    },
});

// Search state variables
const searchQuery = ref('');
const searchType = ref('query');
const searchResults = ref(null);
const isSearching = ref(false);

// Perform search with selected criteria
const search = async () => {
    if (!searchQuery.value) {
        searchResults.value = null;
        return;
    }

    isSearching.value = true;

    try {
        const params = {};
        params[searchType.value] = searchQuery.value;

        const response = await axios.get('/articles/api/public-search', { params });
        searchResults.value = response.data;
    } finally {
        isSearching.value = false;
    }
};

// Handle pagination for search results
const handleAjaxPagination = async (url) => {
    if (!url) return;

    isSearching.value = true;
    try {
        const urlObj = new URL(url);

        if (searchQuery.value) {
            urlObj.searchParams.set(searchType.value, searchQuery.value);
        }

        const response = await axios.get(urlObj.toString());
        searchResults.value = response.data;
    } finally {
        isSearching.value = false;
    }
};

// Trigger search when query or type changes
watch(searchQuery, search);
watch(searchType, search);

const page = usePage();

// Navigate to appropriate article view based on authentication status
const viewArticle = (articleId) => {
    if (page.props.auth.user) {
        router.visit(`/articles/${articleId}`);
    } else {
        router.visit(`/articles/guest/${articleId}`);
    }
};
</script>

<template>
    <Head title="Benvingut" />
    <div class="bg-gradient-to-br from-blue-100 via-purple-200 to-pink-100 min-h-screen text-gray-800">
        <!-- Header with navigation -->
        <header class="bg-gradient-to-r from-purple-500 to-pink-500 text-white py-6 shadow-lg">
            <div class="container mx-auto flex justify-between items-center px-6">
                <h1
                    class="relative top-0 w-fit h-auto py-4 justify-center flex bg-white items-center bg-clip-text text-4xl font-extrabold text-transparent text-center select-auto">
                    Benvinguts a la nostra web
                </h1>
                <nav v-if="canLogin" class="flex space-x-4">
                    <Link v-if="$page.props.auth.user" :href="route('dashboard')"
                        class="bg-white text-purple-600 font-bold rounded-md px-4 py-2 text-sm shadow-xl hover:bg-gray-100">
                    Inici
                    </Link>
                    <template v-else>
                        <Link :href="route('login')"
                            class="bg-white text-purple-600 font-bold rounded-md px-4 py-2 text-sm shadow-md hover:bg-gray-100">
                        Iniciar Sessió
                        </Link>
                        <Link v-if="canRegister" :href="route('register')"
                            class="bg-white text-purple-600 font-bold rounded-md px-4 py-2 text-sm shadow-md hover:bg-gray-100">
                        Registrar-se
                        </Link>
                    </template>
                </nav>
            </div>
        </header>

        <div class="py-12 bg-gradient-to-br from-blue-100 via-purple-200 to-pink-100">
            <div class="mx-auto max-w-7xl sm:px-6 lg:px-8">
                <!-- Search form -->
                <div class="bg-white p-4 mb-6 rounded-lg shadow-sm">
                    <form @submit.prevent class="flex flex-col sm:flex-row gap-2">
                        <select id="search-type" name="search-type" v-model="searchType"
                            class="rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500">
                            <option value="query">Cercar a tot arreu</option>
                            <option value="title">Cercar per títol</option>
                            <option value="description">Cercar per descripció</option>
                            <option value="author">Cercar per autor</option>
                            <option value="labels">Cercar per etiqueta</option>
                        </select>
                        <input id="search-query" name="search-query" type="text" v-model="searchQuery"
                            placeholder="Cerca articles..."
                            class="flex-1 rounded-md border-gray-300 shadow-sm focus:border-indigo-500 focus:ring-indigo-500" />
                    </form>
                </div>

                <!-- Articles container -->
                <div class="overflow-hidden bg-white shadow-sm sm:rounded-lg">
                    <div class="p-6 text-gray-900">
                        <!-- Loading state -->
                        <div v-if="isSearching" class="text-center py-4">
                            Cercant articles...
                        </div>

                        <h2 class="text-xl font-semibold mb-4">
                            {{ searchResults ? 'Resultats de cerca:' : 'Articles publicats:' }}
                        </h2>

                        <!-- Article grid with card components -->
                        <div v-if="(searchResults || props.articles).data && (searchResults || props.articles).data.length"
                            class="overflow-hidden bg-white shadow-sm sm:rounded-lg p-6 text-white text-bold-900">
                            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                                <div v-for="article in (searchResults || props.articles).data" :key="article.id">
                                    <Card :article="article" @view-article="viewArticle" />
                                </div>
                            </div>
                            
                            <!-- Pagination - different component based on search state -->
                            <div class="mt-8 text-gray-900">
                                <AjaxPaginationLinks v-if="searchResults" :paginator="searchResults"
                                    @paginate="handleAjaxPagination" />
                                <PaginationLinks v-else :paginator="props.articles" />
                            </div>
                        </div>
                        
                        <!-- Empty state -->
                        <div v-else class="text-center py-8">
                            No s'han trobat articles.
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <Footer />
    </div>
    <CookieBanner />
</template>