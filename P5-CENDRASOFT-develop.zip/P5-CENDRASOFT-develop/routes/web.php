<?php

use App\Http\Controllers\ProfileController;
use App\Http\Controllers\ArticleController;
use App\Http\Controllers\CategoryController;
use Illuminate\Foundation\Application;
use Illuminate\Support\Facades\Route;
use Inertia\Inertia;
use App\Models\Article;

Route::get('/', function () {
    $articles = Article::with('user')->latest()->paginate(6);
    return Inertia::render('Welcome', [
        'canLogin' => Route::has('login'),
        'canRegister' => Route::has('register'),
        'laravelVersion' => Application::VERSION,
        'phpVersion' => PHP_VERSION,
        'articles' => $articles,
    ]);
});

Route::middleware(['auth', 'verified'])->group(function () {
    // Dashboard
    Route::get('/dashboard', fn() => Inertia::render('Dashboard'))->name('dashboard');

    // Profile routes
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');

    // Article routes
    Route::get('/article', [ArticleController::class, 'index'])->name('article');
    Route::resource('article', ArticleController::class)->except('index');
    Route::get('/articles/api/search', [ArticleController::class, 'searchApi']);

    // Category routes
    Route::get('/categories', [CategoryController::class, 'index'])->name('category');
    Route::post('/categories', [CategoryController::class, 'store'])->name('category.store');
    Route::delete('/categories/{category}', [CategoryController::class, 'destroy'])->name('category.destroy');
    Route::get('/categories/all', [CategoryController::class, 'getAll'])->name('categories.all');
});

// Public routes
Route::get('/articles/api/public-search', [ArticleController::class, 'publicSearch'])->name('articles.api.public-search');
Route::get('/articles/{id}', [ArticleController::class, 'show'])->name('articles.show');
// Public article routes
Route::get('/articles/guest/{id}', [ArticleController::class, 'guestShow'])->name('article.guest-show');

// Legal and informational page routes
Route::get('/legal-notice', function () {
    return Inertia::render('LegalNotice');
})->name('legal-notice');

Route::get('/privacy-policy', function () {
    return Inertia::render('PrivacyPolicy');
})->name('privacy-policy');

Route::get('/cookie-policy', function () {
    return Inertia::render('CookiePolicy');
})->name('cookie-policy');

Route::get('/contact', function () {
    return Inertia::render('Contact');
})->name('contact');

Route::get('/developers', function () {
    return Inertia::render('Developers');
})->name('developers');

require __DIR__ . '/auth.php';
