<?php

use App\Models\Article;
use App\Models\User;
use App\Models\Category;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;

beforeEach(function () {
    $this->category = Category::factory()->create(['name' => 'Test Category']);
});

test('a logged-in user can create an article', function () {
    $user = User::factory()->create();
    $this->actingAs($user);

    Storage::fake('public');
    $image = UploadedFile::fake()->image('test-image.jpg', 500, 500);

    $articleData = [
        'title' => 'Test Article Title',
        'description' => 'Test description with **bold** text.',
        'labels' => json_encode(['test', 'laravel']),
        'category_id' => $this->category->id,
        'image' => $image,
    ];

    $response = $this->post(route('article.store'), $articleData);

    $response->assertRedirect(route('article'));
    $response->assertSessionHas('status', 'Article creat correctament');

    $this->assertDatabaseHas('articles', [
        'title' => 'Test Article Title',
        'user_id' => $user->id,
    ]);

    $article = Article::where('title', 'Test Article Title')->first();
    expect($article->description)->toBe('Test description with **bold** text.');
    expect($article->category_id)->toBe($this->category->id);
    expect($article->labels)->toContain('test');
    expect($article->labels)->toContain('laravel');
    
    if ($article->image) {
        $this->assertTrue(Storage::disk('public')->exists($article->image), 'The image file does not exist in the storage.');
    }
});

test('a user cannot edit someone else\'s article', function () {
    $owner = User::factory()->create();
    $otherUser = User::factory()->create();

    $article = Article::factory()->create([
        'user_id' => $owner->id,
        'category_id' => $this->category->id,
        'title' => 'Original Title',
        'description' => 'Original description',
        'labels' => ['original']
    ]);

    $this->actingAs($otherUser);

    $updatedData = [
        'title' => 'Updated Title',
        'description' => 'Updated description',
        'labels' => json_encode(['updated']),
        'category_id' => $this->category->id
    ];

    $response = $this->put(route('article.update', $article->id), $updatedData);
    $response->assertStatus(302);

    $this->assertDatabaseHas('articles', [
        'id' => $article->id,
        'title' => 'Original Title',
        'description' => 'Original description'
    ]);

    $response = $this->get(route('article.edit', $article->id));
    $response->assertRedirect();
});

test('articles can be filtered by label', function () {
    $user = User::factory()->create();
    $this->actingAs($user);
    
    $scienceArticle1 = Article::factory()->create([
        'user_id' => $user->id,
        'category_id' => $this->category->id,
        'labels' => ['science', 'research']
    ]);
    
    $scienceArticle2 = Article::factory()->create([
        'user_id' => $user->id,
        'category_id' => $this->category->id,
        'labels' => ['science', 'technology']
    ]);
    
    $historyArticle = Article::factory()->create([
        'user_id' => $user->id,
        'category_id' => $this->category->id,
        'labels' => ['history', 'ancient']
    ]);
    
    // Test science label filter
    $response = $this->getJson('/articles/api/search?labels=science');
    $response->assertStatus(200);
    $responseData = $response->json();
    
    // Check science articles are included
    $this->assertTrue(collect($responseData['data'])->contains(fn($item) => $item['id'] === $scienceArticle1->id));
    $this->assertTrue(collect($responseData['data'])->contains(fn($item) => $item['id'] === $scienceArticle2->id));
    // Check history article is excluded
    $this->assertFalse(collect($responseData['data'])->contains(fn($item) => $item['id'] === $historyArticle->id));
    
    // Test history label filter
    $response = $this->getJson('/articles/api/search?labels=history');
    $responseData = $response->json();
    
    // Check history article is included
    $this->assertTrue(collect($responseData['data'])->contains(fn($item) => $item['id'] === $historyArticle->id));
    // Check science article is excluded
    $this->assertFalse(collect($responseData['data'])->contains(fn($item) => $item['id'] === $scienceArticle1->id));
});