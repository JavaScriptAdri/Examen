import { mount } from '@vue/test-utils';
import { describe, it, expect } from 'vitest';

const CardStub = {
    name: 'Card',
    template: `
    <div>
      <h2 class="font-bold text-xl text-white">{{ article.title }}</h2>
      <p class="text-white">{{ article.user.name }}</p>
      <div v-for="label in article.labels" :key="label">
        <span class="bg-blue-800 text-white px-2 py-px rounded-full">{{ label }}</span>
      </div>
    </div>
  `,
    props: ['article']
};

describe('Article Card Component', () => {
    it('displays title, author, and labels correctly', async () => {
        const article = {
            id: 1,
            title: 'Exploring Solar Energy',
            description: 'A guide to solar panel technology.',
            user: { id: 2, name: 'Alice Smith' },
            labels: ['solar', 'energy', 'renewable'],
            created_at: '2025-04-10T12:00:00'
        };

        const wrapper = mount(CardStub, { props: { article } });

        // Check title
        expect(wrapper.find('h2').text()).toContain('Exploring Solar Energy');

        // Check author
        expect(wrapper.find('p').text()).toContain('Alice Smith');

        // Check labels
        const labelElements = wrapper.findAll('.bg-blue-800');
        expect(labelElements.length).toBe(3);
        expect(labelElements.map(el => el.text())).toContain('solar');
        expect(labelElements.map(el => el.text())).toContain('energy');
        expect(labelElements.map(el => el.text())).toContain('renewable');
    });
});