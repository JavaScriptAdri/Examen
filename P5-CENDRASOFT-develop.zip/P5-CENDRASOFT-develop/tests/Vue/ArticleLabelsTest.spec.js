import { mount } from '@vue/test-utils';
import { describe, it, expect } from 'vitest';

const CardStub = {
    name: 'Card',
    template: `
    <div v-if="article.labels">
      <div v-for="label in article.labels" :key="label">
        <span class="bg-blue-800 text-white px-2 py-px rounded-full">{{ label }}</span>
      </div>
    </div>
  `,
    props: ['article']
};

describe('Article Component Labels', () => {
    it('displays tags properly when passed to the component', async () => {
        const article = {
            id: 1,
            title: 'Nature Conservation',
            labels: ['science', 'nature', 'conservation']
        };

        const wrapper = mount(CardStub, { props: { article } });
        const labelElements = wrapper.findAll('.bg-blue-800');

        // Check count
        expect(labelElements.length).toBe(3);

        // Check content
        const labelTexts = labelElements.map(el => el.text());
        expect(labelTexts).toContain('science');
        expect(labelTexts).toContain('nature');
        expect(labelTexts).toContain('conservation');
    });
});