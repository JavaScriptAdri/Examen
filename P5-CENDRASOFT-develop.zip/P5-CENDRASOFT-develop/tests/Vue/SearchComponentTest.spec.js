import { mount, flushPromises } from '@vue/test-utils';
import { describe, it, expect, beforeEach } from 'vitest';
import axios from 'axios';
import MockAdapter from 'axios-mock-adapter';

const mockAxios = new MockAdapter(axios);

const ArticleStub = {
    template: `
    <div>
      <input id="search-query" v-model="searchQuery" />
      <div v-for="article in displayedArticles" :key="article.id" data-testid="article-card">
        {{ article.title }}
      </div>
    </div>
  `,
    props: ['articles'],
    data() {
        return {
            searchQuery: '',
            searchResults: null
        };
    },
    computed: {
        displayedArticles() {
            return (this.searchResults?.data || this.articles.data);
        }
    },
    methods: {
        async search() {
            if (!this.searchQuery) {
                this.searchResults = null;
                return;
            }

            const response = await axios.get('/articles/api/search', {
                params: { query: this.searchQuery }
            });
            this.searchResults = response.data;
        }
    }
};

describe('Search Component', () => {
    beforeEach(() => {
        mockAxios.reset();
        mockAxios.onGet('/articles/api/search').reply(200, {
            data: [
                {
                    id: 1,
                    title: 'Clean Energy Solutions',
                    labels: ['energy', 'renewable']
                }
            ]
        });
    });

    it('filters correctly when user searches', async () => {
        // Set up test data
        const articles = {
            data: [
                { id: 1, title: 'Clean Energy Solutions', labels: ['energy', 'renewable'] },
                { id: 2, title: 'Web Development', labels: ['coding', 'web'] }
            ]
        };

        const wrapper = mount(ArticleStub, { props: { articles } });
        expect(wrapper.findAll('[data-testid="article-card"]').length).toBe(2);

        // Perform search
        await wrapper.setData({ searchQuery: 'energy' });
        await wrapper.vm.search();
        await flushPromises();

        // Verify filtering worked
        expect(wrapper.findAll('[data-testid="article-card"]').length).toBe(1);
        expect(wrapper.text()).toContain('Clean Energy Solutions');
        expect(wrapper.text()).not.toContain('Web Development');
    });
});